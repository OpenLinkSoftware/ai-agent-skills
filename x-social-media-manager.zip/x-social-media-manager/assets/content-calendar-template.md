# Weekly Content Calendar Template

## Week of: [DATE]

---

## Content Mix Target

| Type | Target % | Target Posts | Actual |
|------|----------|--------------|--------|
| Value/Educational | 40% | ___ | [ ] |
| Engagement/Questions | 25% | ___ | [ ] |
| Personal/Story | 20% | ___ | [ ] |
| Promotional | 15% | ___ | [ ] |

---

## Monday

### Post 1 - Morning (8-10 AM)
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 2 - Midday (12-1 PM)
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 3 - Evening (5-7 PM)
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

---

## Tuesday

### Post 1 - Morning
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 2 - Midday
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 3 - Evening
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

---

## Wednesday

### Post 1 - Morning
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 2 - Midday
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 3 - Evening
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

---

## Thursday

### Post 1 - Morning
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 2 - Midday
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 3 - Evening
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

---

## Friday

### Post 1 - Morning
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 2 - Midday
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 3 - Evening
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

---

## Saturday (Reduced)

### Post 1 - Late Morning (9-11 AM)
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 2 - Evening
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

---

## Sunday (Reduced)

### Post 1 - Late Morning (9-11 AM)
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

### Post 2 - Evening
- **Type**: 
- **Format**: 
- **Topic/Angle**: 
- **Hook**: 
- **Engagement Goal**: 
- **Draft**:
```


```
- [ ] Written
- [ ] Reviewed
- [ ] Scheduled

---

## Weekly Review

### Metrics to Track
| Metric | Monday | Tuesday | Wednesday | Thursday | Friday | Saturday | Sunday | Total |
|--------|--------|---------|-----------|----------|--------|----------|--------|-------|
| Impressions | | | | | | | | |
| Engagements | | | | | | | | |
| Profile Visits | | | | | | | | |
| New Followers | | | | | | | | |
| Link Clicks | | | | | | | | |

### Top Performing Post
- **Post**: 
- **Why it worked**: 
- **Learnings**: 

### Lowest Performing Post
- **Post**: 
- **Why it underperformed**: 
- **Improvements**: 

### Key Learnings
1. 
2. 
3. 

### Adjustments for Next Week
1. 
2. 
3. 

---

## Content Ideas Bank

Capture ideas throughout the week:

1. 
2. 
3. 
4. 
5. 
6. 
7. 
8. 
9. 
10. 

---

## Engagement Tasks

### Daily
- [ ] Respond to all comments within 2 hours
- [ ] Reply to 5-10 accounts in your niche
- [ ] Engage with new followers

### Weekly
- [ ] Review analytics
- [ ] Update content calendar
- [ ] Batch create next week's content
- [ ] Optimize bio/pinned tweet if needed
