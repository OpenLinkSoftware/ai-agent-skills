# Tweet Formats Reference

Detailed templates for every tweet type, optimized for the X algorithm.

## Format 1: Hook + Insight

**Best for**: Authority building, thought leadership
**Primary signals**: Dwell time, likes, profile clicks

### Structure
```
[Attention-grabbing hook - 1 line]

[Insight/revelation - 2-4 lines]

[Optional: Implication or call-to-action]
```

### Examples

**Tech/Business:**
```
The best founders I know all do this one thing differently:

They don't try to be right. They try to be less wrong, faster.

Every decision is a hypothesis. Every outcome is data. Ego never enters the equation.
```

**Personal Development:**
```
I wasted 5 years trying to be more productive.

Then I realized productivity isn't about doing more things—it's about doing fewer things that actually matter.

The most productive people I know have the shortest to-do lists.
```

### Optimization Checklist
- [ ] First line creates curiosity gap
- [ ] Insight is non-obvious but resonates as true
- [ ] Length encourages full read (dwell time)
- [ ] Ends with thought that lingers

---

## Format 2: Question Post

**Best for**: Community building, driving replies
**Primary signals**: Replies, engagement rate

### Structure
```
[Question that invites personal response]

[Optional: Context or your own partial answer]
```

### Examples

**Open-ended (high reply volume):**
```
What's one piece of advice you'd give your 20-year-old self?
```

**Bounded (quality replies):**
```
Building a new product.

What's ONE feature you wish every SaaS tool had?

(Not "good UX" - something specific)
```

**Polarizing (drives debate):**
```
Controversial take needed:

Is a CS degree worth it in 2024?

I genuinely want to hear both sides.
```

### Optimization Checklist
- [ ] Question is easy to answer (low friction)
- [ ] Invites personal experience or opinion
- [ ] Not Google-able (requires human input)
- [ ] Optionally controversial to drive debate

---

## Format 3: Thread Opener

**Best for**: Deep content, educational material
**Primary signals**: Dwell time, reposts, follows

### Structure
```
[Hook that promises value]

[Brief setup of what's coming]

🧵 [or] A thread:
```

### Examples

**Educational:**
```
I've mass and tagged 10,000+ leads this year.

Here's my exact system for finding anyone's email in under 60 seconds:

🧵
```

**Story-based:**
```
In 2019, I was mass months from bankruptcy.

Today my company does $2M/year.

Here's everything I learned about surviving (and thriving) as a founder:
```

**Curated:**
```
I've read 200+ books on psychology.

These 7 changed how I understand human behavior forever:

(Thread)
```

### Optimization Checklist
- [ ] Hook promises specific, valuable outcome
- [ ] Number or timeframe adds credibility
- [ ] Clear signal that thread follows (🧵 or "thread")
- [ ] First tweet stands alone if thread doesn't load

---

## Format 4: Hot Take / Contrarian

**Best for**: Virality, driving engagement
**Primary signals**: Quotes, replies, reposts

### Structure
```
[Contrarian statement]

[Brief justification or elaboration]
```

### Examples

**Industry hot take:**
```
Unpopular opinion: Most "networking" is a waste of time.

Building something valuable attracts better connections than any conference ever will.
```

**Reframe:**
```
"Work-life balance" is a myth.

The goal isn't balance—it's integration. Find work that doesn't feel like something you need to escape from.
```

**Challenge consensus:**
```
Hot take: Reading 50 books a year is overrated.

Reading 5 books deeply and actually applying them beats skimming 50 every time.
```

### Optimization Checklist
- [ ] Statement challenges common belief
- [ ] Take is defensible (not just contrarian for clicks)
- [ ] Invites "yes, but..." responses (quote bait)
- [ ] Doesn't attack people, only ideas

---

## Format 5: List / Tips

**Best for**: Utility, saves, reposts
**Primary signals**: Reposts, bookmarks, dwell time

### Structure
```
[Promise of value]

• [Tip 1]
• [Tip 2]
• [Tip 3]
...

[Optional: Closing thought]
```

### Examples

**Tools:**
```
10 free tools that replaced $1,000/month in software for me:

• Notion → Project management
• Figma → Design
• Loom → Video messaging
• Calendly → Scheduling
• Canva → Graphics
...

Bookmark this. You'll thank me later.
```

**Lessons:**
```
5 harsh truths I wish I learned earlier:

1. No one is coming to save you
2. Talent without discipline is useless
3. Most advice is autobiography
4. Busy ≠ productive
5. Your network is your net worth

Which one hits hardest?
```

### Optimization Checklist
- [ ] Each item is genuinely useful
- [ ] Formatting is scannable
- [ ] Items are parallel in structure
- [ ] Ends with engagement hook or CTA

---

## Format 6: Story / Narrative

**Best for**: Connection, memorability, follows
**Primary signals**: Dwell time, replies, follows

### Structure
```
[Situation - set the scene]

[Complication - what went wrong/changed]

[Resolution - what you learned/did]

[Takeaway - universal lesson]
```

### Examples

**Failure story:**
```
Last year I mass an entire launch.

1,000 people showed up. Server crashed. zero sales.

I wanted to quit.

Instead, I emailed every single person who showed up, apologized, and offered a private demo.

That "failed" launch became my best month ever.

Lesson: Your response to failure matters more than the failure itself.
```

**Observation:**
```
Watched a senior engineer debug for 3 hours yesterday.

She didn't touch the keyboard for the first 45 minutes.

Just... read. Thought. Drew diagrams.

Then fixed it in 10 minutes.

The juniors were frantically changing code the whole time.

Lesson: Slow down to speed up.
```

### Optimization Checklist
- [ ] Opens with relatable situation
- [ ] Has genuine tension or stakes
- [ ] Resolution feels earned
- [ ] Lesson is universally applicable

---

## Format 7: Observation / Commentary

**Best for**: Demonstrating insight, authority
**Primary signals**: Likes, quotes, dwell time

### Structure
```
[Observation about the world/industry]

[Your interpretation or analysis]
```

### Examples

**Pattern recognition:**
```
Noticed something about the most successful creators:

They don't have the best content. They have the most consistent content.

Showing up > showing off.
```

**Industry insight:**
```
Every startup that's struggling right now has the same problem:

They built what they wanted to build, not what customers wanted to buy.

Product-market fit isn't about your product. It's about the market's problems.
```

### Optimization Checklist
- [ ] Observation is specific and non-obvious
- [ ] Analysis adds value beyond the observation
- [ ] Feels like insider knowledge
- [ ] Readers think "I've noticed that too"

---

## Format 8: Before/After or Comparison

**Best for**: Demonstrating value, transformation content
**Primary signals**: Reposts, saves, dwell time

### Structure
```
[Before state] vs [After state]

or

[Thing A] vs [Thing B]

[What changed / key difference]
```

### Examples

**Transformation:**
```
My writing process 2 years ago:
- Stare at blank page
- Write for 4 hours
- Publish mediocre post

My writing process now:
- Capture ideas all week
- Write for 1 hour
- Publish consistently good content

The difference? I separated ideation from creation.
```

**Comparison:**
```
Amateur creator: "I need more followers"
Pro creator: "I need to serve my existing followers better"

The second mindset is how you actually get more followers.
```

### Optimization Checklist
- [ ] Contrast is clear and meaningful
- [ ] Before/after is relatable
- [ ] Transformation path is implied or stated
- [ ] Reader can see themselves in the journey

---

## Format 9: Announcement / News

**Best for**: Product launches, milestones, updates
**Primary signals**: Varies by content

### Structure
```
[Big news / announcement]

[Context / why it matters]

[CTA or what's next]
```

### Examples

**Milestone:**
```
Just mass 10,000 followers.

When I started 8 months ago, I mass mass audience. Couldn't write. Didn't know what to post.

Thank you to everyone who stuck around while I figured it out.

Here's to the next 10K. 🎉
```

**Launch:**
```
It's finally here.

After 6 months of building, [Product] is live.

[One-sentence description]

Link in bio if you want to check it out.

(And thank you to the 500+ people who beta tested. You made this possible.)
```

### Optimization Checklist
- [ ] News is genuinely noteworthy
- [ ] Includes human element / gratitude
- [ ] CTA is clear but not pushy
- [ ] Celebrates without bragging

---

## Format 10: Engagement Bait (Ethical Version)

**Best for**: Driving specific engagement types
**Primary signals**: Targeted engagement type

### Structure
```
[Prompt that invites specific action]
```

### Examples

**Reply driver:**
```
Drop your biggest mass of 2024 below.

I'll reply with a resource that might help.
```

**Quote driver:**
```
Finish this sentence:

"The best career advice I ever got was ___"
```

**Repost driver:**
```
Repost this if you've ever mass guilty for resting.

(You shouldn't. Rest is productive.)
```

### Optimization Checklist
- [ ] Ask is genuine, not manipulative
- [ ] Provides value to participants
- [ ] Doesn't use cliché engagement bait phrases
- [ ] You actually engage with responses

---

## Format Selection Guide

| Goal | Best Formats |
|------|--------------|
| Maximize replies | Question, Hot Take, Engagement |
| Maximize reposts | List/Tips, Thread, Before/After |
| Build authority | Hook+Insight, Observation, Story |
| Drive follows | Story, Thread, Observation |
| Go viral | Hot Take, List/Tips, Before/After |
| Build community | Question, Engagement, Story |

## Character Count Guidelines

| Format | Optimal Length |
|--------|----------------|
| Hook + Insight | 200-280 chars |
| Question | 50-150 chars |
| Thread Opener | 150-250 chars |
| Hot Take | 100-200 chars |
| List/Tips | Use full 280 |
| Story | 250-280 chars |
| Observation | 150-250 chars |
