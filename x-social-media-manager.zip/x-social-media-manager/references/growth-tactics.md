# Growth Tactics for X

Follower growth on X is a function of impressions × follow rate. The algorithm determines impressions; your content determines follow rate. These tactics optimize both.

## Understanding the Follow Decision

Users follow accounts when they believe:
1. **Future value**: "This account will post more content I want to see"
2. **Authority signal**: "Following this person signals something about me"
3. **Community access**: "This is my tribe/industry/interest group"
4. **FOMO**: "I'll miss out if I don't follow"

Your growth strategy must address these psychological triggers.

## The Growth Flywheel

```
┌─────────────────────────────────────────────────────────────────┐
│                        GROWTH FLYWHEEL                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│    ┌──────────────┐                                              │
│    │ Great Content │◄───────────────────────────────┐            │
│    └──────┬───────┘                                 │            │
│           │                                         │            │
│           ▼                                         │            │
│    ┌──────────────┐                                 │            │
│    │ Engagement   │                                 │            │
│    └──────┬───────┘                                 │            │
│           │                                         │            │
│           ▼                                         │            │
│    ┌──────────────┐                                 │            │
│    │ Algorithm    │                                 │            │
│    │ Distribution │                                 │            │
│    └──────┬───────┘                                 │            │
│           │                                         │            │
│           ▼                                         │            │
│    ┌──────────────┐                                 │            │
│    │ New Followers│─────────────────────────────────┘            │
│    └──────────────┘                                              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Profile Optimization

Your profile converts visitors to followers. Optimize every element.

### Profile Picture
- Clear face or recognizable logo
- High contrast (stands out in timeline)
- Consistent across platforms
- Professional but approachable

### Display Name
```
Format: [Name] | [Value Proposition]

Examples:
• Alex Chen | Growth Marketing
• Sarah K 📈 SaaS Advisor
• Mike | Building @StartupName
```

### Bio Structure
```
Line 1: What you do / who you help
Line 2: Credibility indicator
Line 3: What followers get
Line 4: CTA or personality

Example:
"Helping B2B startups 10x their content
Former Head of Growth @BigCo
Daily tips on content strategy + SEO
🏔️ Colorado | ☕ Coffee snob"
```

### Pinned Tweet
Pin your single best piece of content. Update monthly.

Best pinned tweet types:
1. Best-performing thread
2. "Start here" introduction
3. Lead magnet or resource
4. Recent achievement with proof

### Link
Options:
- Newsletter signup
- Best content page
- Lead magnet
- Personal site
- LinkTree (if multiple)

## Content-Driven Growth Tactics

### Tactic 1: The Authority Thread

Create a definitive thread on your core topic. The goal is to be bookmarked, shared, and referenced.

```
"The Complete Guide to [Your Topic]

Everything I've learned in [X] years.

(Bookmark this thread)

🧵"
```

This becomes your "business card" thread that you can reference and reshare.

### Tactic 2: The Teardown/Breakdown

Analyze something popular and extract insights.

```
"I spent 5 hours analyzing @[BigAccount]'s growth strategy.

Here's what I found:

🧵"
```

Benefits:
- Borrows authority from the subject
- May get shared by the subject
- Provides unique value
- Demonstrates expertise

### Tactic 3: The Challenge

Create a public challenge with progress updates.

```
"I'm going to [ambitious goal] in [timeframe].

Follow along as I document everything.

Day 1/30: 🧵"
```

Benefits:
- Built-in content calendar
- Narrative hook for follows
- Accountability creates engagement
- Transformation arc

### Tactic 4: The Contrarian Thread Series

Develop a reputation for challenging industry assumptions.

```
"[Industry] myths that need to die:

A thread series I'll add to every week.

🧵"
```

Benefits:
- Creates recurring content format
- Builds "contrarian expert" brand
- High engagement from debate
- Follow-worthy for unique perspective

### Tactic 5: The Curation Play

Become the go-to curator for your niche.

```
"Every [day/week], I share the best [thing] I found.

Follow for curated [topic] content.

This week's finds: 🧵"
```

Benefits:
- Lower content creation burden
- Positions you as tastemaker
- Builds relationships with featured accounts
- Follow-worthy for discovery value

## Engagement-Driven Growth Tactics

### Tactic 6: Strategic Commenting

Comment on larger accounts in your niche with value-adding insights.

Rules:
1. Add genuine value (not "Great post!")
2. Comment early (within 30 minutes)
3. Be first or be best
4. Reply to replies (creates sub-threads)
5. Never self-promote directly

### Tactic 7: The Collaboration

Partner with similar-sized accounts for mutual growth.

Formats:
- Joint threads (alternating tweets)
- Interview threads
- Mutual shoutouts
- Co-created resources

### Tactic 8: The Quote Tweet Add

Quote tweet larger accounts with substantial additions.

```
[Quote tweet of viral post]

"Adding to this:

[Your unique insight that extends the conversation]"
```

Benefits:
- Borrows their reach
- Shows up in their notifications
- May get liked/RT'd by original author
- Demonstrates your expertise

### Tactic 9: Community Building

Create or participate in X communities around your topic.

- Answer questions thoroughly
- Share exclusive insights
- Recognize active members
- Create community-specific content

## Algorithm-Aligned Growth Tactics

### Tactic 10: Engagement Window Optimization

The first 30-60 minutes determine a tweet's reach. Maximize early engagement:

1. Post when audience is active
2. Engage immediately with all replies
3. Self-reply with additional context
4. DM friends to engage early (carefully)

### Tactic 11: In-Network Maximization

The algorithm prioritizes in-network content. Strengthen your network:

1. Engage with followers' content regularly
2. Build genuine relationships (not just follows)
3. Create content that rewards followers
4. Use "follower-only" framing occasionally

### Tactic 12: Consistency Compounding

The algorithm learns user preferences over time. Be consistent:

1. Post at similar times daily
2. Maintain pillar balance
3. Keep quality consistent
4. Build "appointment viewing" habits

## Growth Metrics to Track

### Primary Metrics

| Metric | Target Growth | How to Improve |
|--------|---------------|----------------|
| Followers | 2-5%/week | Content quality, engagement |
| Profile visits | 10%/week | Hook quality, controversiality |
| Impressions | 15%/week | Engagement, posting frequency |
| Engagement rate | >2% | Content relevance, timing |

### Secondary Metrics

| Metric | Indicator | Action |
|--------|-----------|--------|
| Follow/Unfollow ratio | Content-follower fit | Adjust content pillars |
| Reply rate | Community engagement | Ask more questions |
| Repost rate | Shareability | More frameworks/resources |
| Link clicks | CTA effectiveness | Improve value props |

## Growth Milestones & Strategy Shifts

### 0-1K Followers: Foundation Phase

Focus:
- Defining your niche
- Testing content types
- Building initial relationships
- Learning what resonates

Tactics: Strategic commenting, collaboration, consistency

### 1K-10K Followers: Acceleration Phase

Focus:
- Scaling what works
- Building systems
- Growing authority
- Creating signature content

Tactics: Threads, teardowns, challenges

### 10K-50K Followers: Authority Phase

Focus:
- Becoming the go-to voice
- Selective collaborations
- Content diversification
- Platform expansion

Tactics: Community building, curation, joint ventures

### 50K+ Followers: Scale Phase

Focus:
- Maintaining quality at scale
- Team/systems building
- Monetization optimization
- Brand partnerships

Tactics: Exclusive content, premium offerings, delegation

## Common Growth Mistakes

| Mistake | Impact | Fix |
|---------|--------|-----|
| Inconsistent posting | Algorithm forgets you | Commit to minimum frequency |
| Follow/unfollow schemes | Damages ratio, looks spammy | Organic growth only |
| Engagement pods | Fake signals, no real growth | Build genuine relationships |
| Buying followers | Kills engagement rate | Never do this |
| Too promotional | High unfollow rate | 90% value, 10% promotion |
| Ignoring replies | Missed relationship building | Reply to everyone early on |
| Copying others exactly | No differentiation | Add your unique angle |
| Giving up too early | No compound growth | Commit to 6-12 months |

## The 100-Day Growth Sprint

A structured program for rapid growth:

**Days 1-10: Foundation**
- Optimize profile completely
- Define 3-5 content pillars
- Identify 20 accounts to engage with
- Post 3x daily

**Days 11-30: Content Testing**
- Test different content formats
- Track what gets engagement
- Double down on winners
- Build 5 genuine relationships

**Days 31-60: Scaling Winners**
- Create weekly threads
- Develop signature content series
- Grow engagement relationships
- Optimize posting times

**Days 61-90: Authority Building**
- Launch a challenge or project
- Pursue 3 collaborations
- Create definitive resource
- Build community presence

**Days 91-100: Systemization**
- Document what works
- Create content templates
- Build content calendar
- Set up tracking systems
