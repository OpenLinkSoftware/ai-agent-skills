# Hook Formulas for X

Hooks are the first line of your tweet. They determine whether someone stops scrolling. These formulas are optimized for X's algorithm which rewards dwell time and engagement.

## Curiosity Gap Hooks

Create an information gap that can only be closed by reading more.

```
I spent [TIME] studying [TOPIC]. Here's what nobody talks about:

After [NUMBER] [THINGS], I finally understand why [SURPRISING CONCLUSION].

The difference between [GOOD OUTCOME] and [BAD OUTCOME] comes down to one thing:

[EXPERT/CELEBRITY] taught me something that changed how I think about [TOPIC]:

I was mass today when I realized [INSIGHT].

Everyone talks about [COMMON ADVICE]. Nobody mentions [UNCOMMON TRUTH].

[NUMBER]% of people get [TOPIC] completely wrong. Here's the truth:

I asked [NUMBER] [EXPERTS] the same question. Their answers surprised me:

The biggest lie in [INDUSTRY] is that [COMMON BELIEF].

What [SUCCESSFUL PEOPLE] know about [TOPIC] that you don't:
```

## Contrarian Hooks

Challenge conventional wisdom to spark engagement (replies, quotes).

```
Unpopular opinion: [CONTRARIAN TAKE]

Hot take: [BOLD STATEMENT]

[COMMON ADVICE] is terrible advice. Here's why:

Stop [COMMON PRACTICE]. Start [ALTERNATIVE] instead.

[POPULAR THING] is overrated. [UNPOPULAR THING] is underrated.

The worst advice I ever got: "[COMMON ADVICE]"

I'm going to mass some people off with this one:

[INDUSTRY] doesn't want you to know this:

Everything you've been told about [TOPIC] is wrong.

Delete [COMMON TOOL/APP]. Use [ALTERNATIVE] instead.
```

## Story Hooks

Stories create emotional investment and maximize dwell time.

```
In 2019, I [FAILURE/STRUGGLE]. Today, I [SUCCESS]. Here's what changed:

I lost [SOMETHING VALUABLE] because I didn't understand [LESSON].

A stranger said something to me that I'll never forget:

The moment everything clicked for me was when [SPECIFIC MOMENT].

I made $0 for [TIME PERIOD]. Then I discovered [INSIGHT].

My biggest failure taught me my biggest lesson:

I almost [GAVE UP/QUIT] until [TURNING POINT].

[TIME] ago, I was [BAD SITUATION]. Here's how I turned it around:

The email that changed my life said:

I got fired from [JOB]. Best thing that ever happened to me.
```

## Number/List Hooks

Specific numbers create credibility and set expectations.

```
[NUMBER] [THINGS] I wish I knew [TIME PERIOD] ago:

[NUMBER] signs you're [DOING SOMETHING WRONG]:

[NUMBER] [TOOLS/TACTICS/HABITS] that [BENEFIT]:

[NUMBER] lessons from [ACHIEVEMENT]:

[NUMBER] mistakes killing your [GOAL]:

[NUMBER] things [SUCCESSFUL PEOPLE] do differently:

Here are [NUMBER] [RESOURCES] that will [BENEFIT]:

[NUMBER] [THINGS] I'd tell my younger self:

[NUMBER] [THINGS] that took me [TIME] to learn:

The [NUMBER] [FRAMEWORKS/PRINCIPLES] behind every [SUCCESS]:
```

## Question Hooks

Questions create mental engagement and invite replies.

```
What's stopping you from [DESIRABLE OUTCOME]?

Why do [SOME PEOPLE] succeed while [OTHERS] fail at [THING]?

What would you do if [SCENARIO]?

How many of you [RELATABLE STRUGGLE]?

What's the best [ADVICE/TIP/RESOURCE] you've ever received about [TOPIC]?

Am I the only one who thinks [OPINION]?

What's one thing you wish you started [TIME] ago?

Why doesn't anyone talk about [OVERLOOKED TOPIC]?

Serious question: [THOUGHT-PROVOKING QUESTION]

What's holding [GROUP] back from [GOAL]?
```

## Authority/Credibility Hooks

Establish expertise to build trust and earn follows.

```
After [NUMBER] years in [INDUSTRY], here's what I know for sure:

I've [IMPRESSIVE ACHIEVEMENT]. Here's my playbook:

[NUMBER] [CLIENTS/PROJECTS/DEALS] taught me this:

I've spent [NUMBER]+ hours studying [TOPIC]. Key insights:

My [CREDENTIAL] taught me something school never did:

Working with [IMPRESSIVE CLIENTS/COMPANIES] showed me:

I've [ACHIEVEMENT] and I'm sharing exactly how:

Building [IMPRESSIVE THING] taught me:

[NUMBER] years of [EXPERIENCE] condensed into [FORMAT]:

From [STARTING POINT] to [ACHIEVEMENT] - the real story:
```

## Prediction Hooks

Future-focused statements create urgency and FOMO.

```
In [TIME PERIOD], [PREDICTION]. Here's why:

[THING] is about to change everything. Here's what's coming:

The next [TIME PERIOD] will separate [WINNERS] from [LOSERS].

By [DATE], [PREDICTION]. Prepare now.

[EMERGING TREND] will replace [CURRENT STANDARD].

Most people won't see this coming:

This is the last [TIME PERIOD] to [OPPORTUNITY].

[INDUSTRY] in [FUTURE DATE] will look nothing like today.

The [PEOPLE WHO DO X] will dominate the next decade.

What's coming next will shock most people:
```

## Vulnerable/Personal Hooks

Authenticity builds connection and trust.

```
I'm going to be honest about something:

Here's something I've never shared publicly:

I struggled with [THING] for years. Here's what finally helped:

My biggest insecurity is [VULNERABILITY].

I failed at [THING] more times than I can count.

The truth about [MY SITUATION] that I've been hiding:

I used to [EMBARRASSING PAST]. Now I [BETTER PRESENT].

This is uncomfortable to admit, but:

I almost didn't post this, but:

The part of my journey I don't talk about:
```

## Direct Value Hooks

Promise immediate, specific value.

```
Here's exactly how to [ACHIEVE DESIRABLE OUTCOME]:

The [TIMEFRAME] guide to [GOAL]:

Save this for later - [VALUABLE RESOURCE]:

Free [RESOURCE TYPE]: [SPECIFIC RESOURCE]

How to [GOAL] in [TIMEFRAME] (step-by-step):

The only [GUIDE/FRAMEWORK/TEMPLATE] you need for [TOPIC]:

Copy my exact [SYSTEM/PROCESS/TEMPLATE] for [OUTCOME]:

How I [ACHIEVEMENT] (full breakdown):

[TOPIC] 101 - everything you need to know:

The complete guide to [TOPIC] (thread):
```

## Pattern Interrupt Hooks

Break expected patterns to stop the scroll.

```
This tweet will mass you off.

Forget everything you know about [TOPIC].

I shouldn't share this, but...

This goes against everything you've heard:

Warning: This might change how you see [TOPIC].

Read this if you're tired of [COMMON FRUSTRATION]:

If you're struggling with [PROBLEM], stop what you're doing.

This is the tweet I wish I saw [TIME] ago.

Bookmark this. You'll need it later.

The tweet that would have saved me [TIME/MONEY]:
```

## Hook Optimization Tips

1. **First 5 words matter most** - Front-load impact
2. **Specificity > Vagueness** - "7 lessons" beats "some lessons"
3. **Emotion > Information** - Make them feel something
4. **Break mid-thought** - Create tension that demands resolution
5. **Match hook to content** - Don't bait-and-switch
6. **Test variations** - Same content, different hooks = different results
