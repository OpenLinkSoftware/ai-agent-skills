# Viral Content Patterns for X

These patterns are reverse-engineered from high-performing content and aligned with X's algorithm signals. Virality = maximizing positive engagement signals while minimizing negative ones.

## The Viral Score Formula

Based on X's algorithm, viral potential is approximated by:

```
Viral Potential = (Reply Likelihood × Reply Weight) +
                  (Repost Likelihood × Repost Weight) +
                  (Like Likelihood × Like Weight) +
                  (Share Likelihood × Share Weight) +
                  (Dwell Time × Dwell Weight) +
                  (Follow Likelihood × Follow Weight) -
                  (Negative Signals × Negative Weights)
```

Content that maximizes multiple signals simultaneously has the highest viral potential.

## High-Performing Content Patterns

### Pattern 1: The Contrarian Take

**Structure:**
```
[Controversial statement that challenges conventional wisdom]

[Reasoning that makes the reader reconsider]

[Invitation to agree or disagree]
```

**Why it works:**
- Stops scroll (pattern interrupt)
- High reply rate (agreement/disagreement)
- High quote rate (people add their take)
- High dwell time (processing the argument)

**Example:**
```
Working more hours doesn't make you more productive.

The most successful people I know work 4-6 focused hours.

The rest is just noise to feel busy.

Agree or disagree?
```

**Signal optimization:**
- ✅ Reply: Strong (invites debate)
- ✅ Quote: Strong (hot take format)
- ✅ Dwell: Medium (requires processing)
- ⚠️ Risk: May trigger "not interested" from some

### Pattern 2: The Framework Drop

**Structure:**
```
[Name of framework]

[Brief description]

[Visual representation or steps]

[Single powerful example]
```

**Why it works:**
- High save/bookmark rate
- High repost rate (people share valuable frameworks)
- Demonstrates expertise (earns follows)
- Easy to reference (gets shared in DMs)

**Example:**
```
The 3-3-3 Method changed how I write:

3 hours of deep work
3 bullet points of ideas  
3 minutes of editing

Most people write linearly.

This method lets you batch your energy.

I went from 1 article/week to 4.
```

**Signal optimization:**
- ✅ Repost: Strong (shareable value)
- ✅ DM Share: Strong (people send to friends)
- ✅ Follow: Strong (demonstrates expertise)
- ✅ Save: Strong (reference material)

### Pattern 3: The Story Arc

**Structure:**
```
[Relatable struggle or failure]

[The turning point or discovery]

[The transformation or lesson]

[The actionable takeaway]
```

**Why it works:**
- Maximum dwell time (narrative tension)
- Emotional engagement (relatability)
- High reply rate (people share their stories)
- Builds parasocial connection (earns follows)

**Example:**
```
I was mass in 2020.

My startup failed. I had $400 in my account.

Then I discovered [skill]. I spent 4 hours/day learning it.

6 months later: $10K/month.

The lesson?

Skills compound. Pick one. Master it. The money follows.
```

**Signal optimization:**
- ✅ Dwell: Very strong (story pulls you through)
- ✅ Reply: Strong (people relate)
- ✅ Follow: Strong (want to see more journey)
- ✅ Repost: Medium (inspirational content)

### Pattern 4: The Specific Number

**Structure:**
```
[Specific quantified claim]

[Breakdown or proof]

[Key insight]
```

**Why it works:**
- Specificity creates credibility
- Numbers stop the scroll
- Easy to evaluate (concrete vs vague)
- Shareable data point

**Example:**
```
I analyzed 1,247 viral tweets.

87% had one thing in common:

They made you feel something in the first line.

Not think. Feel.

Emotion > Information when it comes to hooks.
```

**Signal optimization:**
- ✅ Repost: Strong (shareable insight)
- ✅ Save: Strong (data to reference)
- ✅ Click: Strong (curiosity about methodology)
- ✅ Dwell: Medium (processing the data)

### Pattern 5: The "You're Doing It Wrong"

**Structure:**
```
[Common practice everyone does]

[Why it's wrong]

[The better alternative]

[Proof or example]
```

**Why it works:**
- Pattern interrupt (challenges assumption)
- High reply rate (defensiveness or agreement)
- Value prop is clear (learn the right way)
- Creates fear of missing out

**Example:**
```
Stop ending emails with "Let me know if you have questions."

It puts the burden on them.

Instead: "I'll follow up Thursday unless I hear from you."

This one change increased my reply rate by 43%.
```

**Signal optimization:**
- ✅ Save: Strong (actionable tip)
- ✅ Reply: Strong (agreement or pushback)
- ✅ Repost: Strong (people share fixes)
- ✅ Follow: Medium (want more corrections)

### Pattern 6: The DM-Worthy Resource

**Structure:**
```
[Incredibly useful resource or tool]

[Specific use case]

[How to access or use it]

[Bonus tip or enhancement]
```

**Why it works:**
- Maximum DM share potential
- High save rate
- Genuine value creates goodwill
- People tag others who need it

**Example:**
```
Found a free tool that generates legal contracts:

→ [Tool name]

I used it for:
• NDA
• Freelance agreement  
• Partnership contract

Saved me $2K in lawyer fees.

Pro tip: Edit the liability clause before signing.
```

**Signal optimization:**
- ✅ DM Share: Very strong (people forward to friends)
- ✅ Save: Very strong (reference later)
- ✅ Repost: Strong (people share discoveries)
- ✅ Reply: Medium (people share alternatives)

### Pattern 7: The Prediction

**Structure:**
```
[Bold prediction about the future]

[Evidence or reasoning]

[What to do about it]
```

**Why it works:**
- Creates FOMO
- Positions you as thought leader
- High quote rate (agreement/disagreement)
- Bookmarked to verify later

**Example:**
```
By 2026, 50% of content will be AI-generated.

But here's what will differentiate humans:

• Original research
• Personal stories
• Specific expertise

The "general knowledge" content game is over.

Start building your unique edge now.
```

**Signal optimization:**
- ✅ Quote: Strong (people add their prediction)
- ✅ Save: Strong (verify later)
- ✅ Dwell: Medium (processing implications)
- ✅ Follow: Strong (want to see if you're right)

### Pattern 8: The "Send This To" Hook

**Structure:**
```
[Send this to [specific person who needs it]]

[The value they'll get]

[The content itself]
```

**Why it works:**
- Explicit DM share trigger
- Creates social obligation
- Tags drive visibility
- Becomes inside joke/reference

**Example:**
```
Send this to your friend who "doesn't have time" to exercise:

A 10-minute workout burns more calories than zero minutes.

The best workout is the one you actually do.

Start with 10 minutes. Build from there.

No equipment needed. No excuses allowed.
```

**Signal optimization:**
- ✅ DM Share: Very strong (explicit instruction)
- ✅ Tag: Strong (people @ their friends)
- ✅ Repost: Strong (people share to their audience)
- ✅ Save: Medium (reference for themselves)

## Viral Amplification Tactics

### The 10-Minute Engagement Sprint

Within 10 minutes of posting:
1. Reply to your own tweet with additional context
2. Reply to every comment immediately
3. Like every reply (signals active thread)

This signals "active conversation" to the algorithm.

### The Strategic Self-Quote

2-4 hours after posting:
1. Quote your own tweet
2. Add the single best insight
3. Provide different hook

Captures the second-wave audience.

### The Reply Thread Extension

When a tweet performs well:
1. Add a reply thread underneath
2. Expand on the topic
3. Include additional CTAs

Extracts maximum value from momentum.

## Content Types by Viral Potential

| Content Type | Viral Potential | Primary Signal |
|--------------|-----------------|----------------|
| Contrarian take | Very High | Replies, Quotes |
| Framework/Resource | High | Reposts, Saves |
| Personal story | High | Dwell, Follows |
| Thread | High | Multiple signals |
| Industry news + take | Medium-High | Quotes, Replies |
| How-to tip | Medium | Saves, Reposts |
| Question/Poll | Medium | Replies |
| Curated list | Medium | Saves, Reposts |
| Meme/Humor | Variable | Reposts |
| Plain update | Low | Likes only |

## Anti-Viral Patterns (Avoid These)

### The Engagement Bait
```
❌ "Like if you agree!"
❌ "RT for reach"
❌ "Follow for more"
```
These trigger "not interested" signals and feel desperate.

### The Vague Promise
```
❌ "Here's some advice about success..."
```
Specificity wins. Vagueness loses.

### The Humble Brag
```
❌ "So humbled to announce my $10M round..."
```
Bragging without value creates negative sentiment.

### The Wall of Text
```
❌ [280 characters with no line breaks]
```
Dense text kills dwell time. People scroll past.

### The Reply Guy
```
❌ [Promoting yourself in others' replies]
```
Damages reputation, triggers blocks/mutes.
