# X Algorithm Deep Dive

This document contains detailed technical knowledge of X's recommendation algorithm, reverse-engineered from the open-source release. Use this for advanced optimization strategies.

## System Architecture Overview

X's "For You" feed is powered by a multi-stage recommendation pipeline:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           FOR YOU FEED REQUEST                               │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              HOME MIXER                                      │
│                         (Orchestration Layer)                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  1. QUERY HYDRATION                                                          │
│     └── Load user engagement history (128 items)                             │
│     └── Load user features (following list, preferences)                     │
│                                                                              │
│  2. CANDIDATE SOURCING                                                       │
│     ├── THUNDER: In-network posts (from accounts you follow)                 │
│     └── PHOENIX RETRIEVAL: Out-of-network posts (ML similarity search)       │
│                                                                              │
│  3. CANDIDATE HYDRATION                                                      │
│     └── Fetch post metadata, author info, media, subscription status         │
│                                                                              │
│  4. PRE-SCORING FILTERS                                                      │
│     └── Remove duplicates, old posts, blocked authors, muted keywords        │
│                                                                              │
│  5. SCORING                                                                  │
│     ├── Phoenix Scorer: ML engagement predictions                            │
│     ├── Weighted Scorer: Combine predictions into final score                │
│     ├── Author Diversity Scorer: Penalize repeated authors                   │
│     └── OON Scorer: Adjust for out-of-network content                        │
│                                                                              │
│  6. SELECTION                                                                │
│     └── Sort by score, select top K candidates                               │
│                                                                              │
│  7. POST-SELECTION FILTERS                                                   │
│     └── Visibility filtering (deleted/spam/violence/etc.)                    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          RANKED FEED RESPONSE                                │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Phoenix: The Ranking Model

Phoenix is X's Grok-based transformer model that predicts engagement probabilities.

### Candidate Isolation: Why It Matters

The attention mask in Phoenix prevents candidates from attending to each other. Your post is scored ONLY against the user's history, not against other posts in the feed.

**Implications for Content Strategy:**

1. Scores are consistent and cacheable
2. Competing posts don't directly affect your score
3. Your content's relevance to a user's past behavior is what matters

### Engagement Predictions

Phoenix outputs probabilities for these engagement types:

- P(favorite), P(reply), P(repost), P(quote), P(click)
- P(profile_click), P(video_view), P(photo_expand)
- P(share), P(dwell), P(follow_author)
- P(not_interested), P(block_author), P(mute_author), P(report)

### Weighted Scoring Formula

```
Final Score = Σ (weight_i × P(action_i))

Positive actions (boost visibility):
  + FAVORITE_WEIGHT × P(favorite)
  + REPLY_WEIGHT × P(reply)
  + RETWEET_WEIGHT × P(repost)
  + SHARE_VIA_DM_WEIGHT × P(share_dm)
  + DWELL_WEIGHT × P(dwell)
  + FOLLOW_AUTHOR_WEIGHT × P(follow)

Negative actions (hurt visibility):
  - NOT_INTERESTED_WEIGHT × P(not_interested)
  - BLOCK_AUTHOR_WEIGHT × P(block)
  - MUTE_AUTHOR_WEIGHT × P(mute)
  - REPORT_WEIGHT × P(report)
```

## Author Diversity Scorer

Prevents any single author from dominating the feed using exponential decay:

```
multiplier = (1.0 - floor) × decay_factor^position + floor
```

**Example (decay_factor=0.5, floor=0.1):**
- 1st post from author: 1.0× multiplier
- 2nd post from author: 0.55× multiplier  
- 3rd post from author: 0.325× multiplier

**Strategic Implication:** Space posts 4+ hours apart to avoid self-competition.

## OON Scorer (Out-of-Network)

Applies a penalty factor to posts from accounts the user doesn't follow.

**Strategic Implication:** Building a genuine following is more valuable than going viral to strangers.

## Filters: What Gets Your Post Removed

| Filter | What It Removes |
|--------|-----------------|
| AgeFilter | Posts older than threshold |
| MutedKeywordFilter | Posts with muted keywords |
| AuthorSocialgraphFilter | Blocked/muted authors |
| VFFilter | Deleted, spam, violent content |

## User Action Sequence

The algorithm loads 128 items of user engagement history including:
- Post and author identifiers
- Multi-hot vector of engagement types
- Product surface (web, iOS, Android)

**Strategic Implication:** Consistent engagement from the same users trains the algorithm to show them more of your content.

## Phoenix Retrieval: Out-of-Network Discovery

Two-tower architecture:
1. User Tower: Encodes user features + engagement history
2. Candidate Tower: Embeds all posts in corpus
3. Similarity Search: Dot product to find matches

**Strategic Implication:** Topic consistency helps your content cluster better for discovery.

## Video Quality View (VQV) Scoring

Videos above minimum duration threshold get VQV_WEIGHT bonus scoring.

## The Score Journey Summary

1. Candidate Sourcing (Thunder for in-network, Phoenix for out-of-network)
2. Phoenix Ranking (compare against user's 128-item history)
3. Weighted Scoring (apply weights to predictions)
4. Author Diversity Decay (penalize multiple posts from same author)
5. OON Adjustment (penalty if user doesn't follow you)
6. Selection (top K make it to feed)
7. User engagement updates their history (cycle continues)
