# Thread Templates

Proven thread structures optimized for the X algorithm. Threads accumulate engagement across tweets, making them powerful for reach and follower growth.

## Why Threads Work

1. **Engagement Compounds**: Each tweet in thread can be liked/replied independently
2. **Dwell Time**: Longer content = more time spent = stronger signal
3. **Repost Value**: Threads are bookmarked and shared as resources
4. **Algorithm Favor**: Thread engagement aggregates to boost visibility

---

## Template 1: The Educational Thread (5-10 tweets)

**Best for**: Teaching concepts, sharing expertise
**Expected engagement**: High reposts, bookmarks, follows

### Structure

```
Tweet 1 (Hook):
[Specific promise of what reader will learn]
[Credibility marker if relevant]
🧵

Tweet 2 (Setup):
[Why this matters / context]
[What most people get wrong]

Tweet 3-N (Value):
[One point per tweet]
[Each tweet should stand alone]
[Use numbers: "1/", "2/", etc. or emoji bullets]

Tweet N-1 (Summary):
[Quick recap of key points]

Tweet N (CTA):
[Follow for more]
[Repost if valuable]
[Drop questions below]
```

### Example

```
Tweet 1:
I mass $0 to $10K/month writing online.

Here's the exact system I used (that most people overcomplicate):

🧵

Tweet 2:
First, let's kill a myth:

You don't need to be an expert. You need to be 2 steps ahead of your reader.

That's it. Here's how to find what those 2 steps are:

Tweet 3:
Step 1: Document, don't create

Stop trying to invent insights. Start writing down what you're already learning.

Every problem you solve is content. Every mistake is a lesson. Every win is a case study.

Tweet 4:
Step 2: Find your "unfair advantage"

What do you know that most people in your field don't?

• Unusual career path?
• Specific skill combo?
• Hard-won experience?

That intersection is your niche.

Tweet 5:
Step 3: Write for one person

Forget "target audience." Picture ONE specific person.

What's their biggest struggle? What do they wish they knew?

Write directly to them. Everyone else will feel like you're talking to them too.

[Continue pattern...]

Tweet 9:
Quick recap:

1. Document what you learn
2. Find your unique angle
3. Write for one person
4. Post consistently
5. Engage genuinely

That's it. No hacks. No tricks.

Tweet 10:
If this was helpful:

1. Follow me @handle for more
2. Repost the first tweet to help others find this

Questions? Drop them below—I read everything.
```

---

## Template 2: The Story Thread (7-12 tweets)

**Best for**: Building connection, memorable content
**Expected engagement**: High replies, follows, dwell time

### Structure

```
Tweet 1 (Hook):
[Dramatic opening or surprising outcome]
[Hint at transformation]

Tweet 2-3 (Setup):
[Set the scene]
[Establish stakes]

Tweet 4-7 (Journey):
[Key moments in chronological order]
[Include setbacks and turning points]
[Each tweet = one scene/moment]

Tweet 8-9 (Resolution):
[How it turned out]
[The transformation]

Tweet 10 (Lesson):
[Universal takeaway]
[What reader can apply]

Tweet 11 (CTA):
[Engagement ask]
```

### Example

```
Tweet 1:
In 2020, I got mass from my dream job.

3 years later, getting mass was the best thing that ever happened to me.

Here's the full story:

Tweet 2:
I was a senior product manager at a top tech company.

Great salary. Great benefits. Great title.

But I was mass. Working 70-hour weeks on products I didn't care about.

Then COVID hit.

Tweet 3:
March 2020. mass off.

I remember sitting in my apartment, refreshing LinkedIn, applying to everything.

200+ applications. 3 interviews. 0 offers.

Rock bottom.

Tweet 4:
One night, I started writing.

Not for an audience. Just to process what I was going through.

I posted it on Twitter. 12 followers. Didn't expect anything.

47 likes. 3 DMs from people going through the same thing.

Tweet 5:
Something clicked.

I kept writing. Every day. About job searching, about rejection, about starting over.

The audience grew slowly. 100 followers. 500. 1,000.

[Continue story...]

Tweet 9:
Today, that "side project" is my full-time business.

I make 3x my old salary.
I work 30 hours a week.
I wake up excited every day.

Getting mass wasn't the end. It was the beginning.

Tweet 10:
The lesson I'll never forget:

Sometimes the worst thing that happens to you is actually the universe redirecting you.

But you have to be willing to walk through the door.

Tweet 11:
If you're going through something hard right now:

Keep going. Document the journey. Your struggle today is someone else's roadmap tomorrow.

What's a setback that turned into your biggest win? 👇
```

---

## Template 3: The Listicle Thread (7-15 tweets)

**Best for**: Tools, resources, tips, examples
**Expected engagement**: Very high reposts, bookmarks

### Structure

```
Tweet 1 (Hook):
[Number + specific promise]
[Why you're qualified to share this]

Tweet 2-N (List items):
[One item per tweet]
[Consistent format: Name → Why it's good → How to use]

Tweet N (Bonus):
[Extra tip or resource]

Tweet N+1 (CTA):
[Bookmark/repost ask]
[Follow for more]
```

### Example

```
Tweet 1:
10 free AI tools that mass me 20+ hours every week:

(Bookmark this—you'll need it)

🧵

Tweet 2:
1. Claude (Anthropic)

Best for: Writing, analysis, coding

I use it for: First drafts, code review, research synthesis

Free tier is incredibly generous. Start here.

Tweet 3:
2. Perplexity AI

Best for: Research with sources

I use it for: Fact-checking, market research, finding data

Like Google but actually answers your question.

Tweet 4:
3. Gamma

Best for: Presentations

I use it for: Turning documents into slide decks in minutes

Killed PowerPoint for me entirely.

[Continue list...]

Tweet 11:
BONUS: How I actually use these together

Morning: Perplexity for research
Afternoon: Claude for writing
Evening: Notion AI for organizing

Stack them. 10x your output.

Tweet 12:
That's it. 10 tools. 20+ hours saved weekly.

If this helped:
• Bookmark for later
• Repost to help others
• Follow @handle for more tool breakdowns

What tool should I cover next? 👇
```

---

## Template 4: The Contrarian Thread (5-8 tweets)

**Best for**: Driving debate, establishing thought leadership
**Expected engagement**: High quotes, replies, polarized reactions

### Structure

```
Tweet 1 (Hot Take):
[Contrarian statement]
[Signal that you'll explain]

Tweet 2 (Acknowledge Other Side):
[Steel-man the opposing view]
[Show you understand why people believe it]

Tweet 3-5 (Your Argument):
[Build your case point by point]
[Use evidence, examples, logic]

Tweet 6 (Nuance):
[When your take DOESN'T apply]
[Show intellectual honesty]

Tweet 7 (Summary):
[Restate position with nuance]

Tweet 8 (Engagement):
[Invite disagreement]
```

### Example

```
Tweet 1:
Unpopular opinion: "Follow your passion" is terrible career advice.

Here's why this well-meaning advice ruins lives:

Tweet 2:
I get why people say it.

Work doesn't feel like work when you love it. Purpose drives performance. Passion creates persistence.

All true. But there's a massive problem nobody talks about:

Tweet 3:
Passion doesn't pay bills. Skills do.

I've met mass of people who "followed their passion" into:
• Saturated markets
• Low-paying fields
• Skills nobody will pay for

Passion without market demand = expensive hobby

Tweet 4:
Here's what actually works:

1. Get good at something valuable
2. Get so good they can't ignore you
3. Use that leverage to do work you care about

Passion follows mastery. Not the other way around.

Tweet 5:
The happiest people I know didn't follow their passion.

They developed rare skills → gained autonomy → shaped their work into something they love.

Cal Newport calls this "career capital." It's real.

Tweet 6:
Now, the nuance:

If you're already financially secure? Follow your passion.
If you have a trust fund? Follow your passion.
If your passion has market demand? Follow your passion.

But for most people? Develop skills first.

Tweet 7:
Better advice than "follow your passion":

"Develop rare and valuable skills, then use the leverage you gain to craft a career you love."

Less catchy. More true.

Tweet 8:
Agree? Disagree? I genuinely want to hear the counterarguments.

What's your experience with this?
```

---

## Template 5: The Breakdown/Analysis Thread (8-12 tweets)

**Best for**: Analyzing trends, companies, strategies
**Expected engagement**: High reposts from niche audiences, authority building

### Structure

```
Tweet 1 (Hook):
[What you're analyzing + why it matters]

Tweet 2 (Context):
[Background needed to understand]

Tweet 3-8 (Analysis):
[Key observations]
[Data points]
[What others miss]

Tweet 9 (Implications):
[What this means going forward]

Tweet 10 (Takeaways):
[Actionable lessons]

Tweet 11 (CTA):
[Engagement ask]
```

### Example

```
Tweet 1:
I spent mass analyzing how Mr Beast mass his thumbnails.

What I found explains why he mass every single video:

🧵

Tweet 2:
First, some context:

Mr Beast tests 20+ thumbnails per video.
His team spends 2-4 hours on each thumbnail.
He's said thumbnails are "50% of the battle."

This isn't an accident. It's a system.

Tweet 3:
Pattern #1: Maximum contrast

Every Beast thumbnail has:
• Bright, saturated colors
• Dark backgrounds or borders
• One dominant focal point

Your eye can't NOT look at it.

[Continue analysis...]

Tweet 10:
Key takeaways you can apply:

1. Test multiple versions
2. Maximize contrast
3. One clear focal point
4. Emotion over information
5. Face = clicks

Thumbnails aren't art. They're engineering.

Tweet 11:
If this breakdown was useful:

• Repost to help other creators
• Follow @handle for more content strategy analysis

What creator should I analyze next?
```

---

## Template 6: The Curated Thread (10-20 tweets)

**Best for**: Resource lists, recommendations, compilations
**Expected engagement**: Extremely high bookmarks and reposts

### Structure

```
Tweet 1 (Hook):
[What you've curated + why it's valuable]
[Your credibility/process]

Tweet 2-N (Items):
[One recommendation per tweet]
[Brief context on why it's included]

Tweet N (How to use):
[Suggest starting point or order]

Tweet N+1 (CTA):
[Save/share ask]
```

---

## Thread Best Practices

### Length Guidelines

| Thread Type | Optimal Length |
|-------------|----------------|
| Educational | 7-10 tweets |
| Story | 8-12 tweets |
| Listicle | 10-15 tweets |
| Contrarian | 5-8 tweets |
| Breakdown | 8-12 tweets |
| Curated | 10-20 tweets |

### Formatting Rules

1. **Number your tweets** (1/, 2/, etc.) for long threads
2. **Each tweet should stand alone** - some people only see one
3. **Use line breaks** - dense text kills engagement
4. **End with CTA** - always tell people what to do next

### Engagement Boosters

1. **Reply to your own thread** with bonus content after posting
2. **Quote tweet** your own thread opener 24-48 hours later
3. **Pin the thread** to your profile
4. **Engage with every reply** in the first hour

### Common Mistakes

1. ❌ Tweets that only make sense in context
2. ❌ Too much filler ("Let me explain...")
3. ❌ Forgetting the CTA
4. ❌ Inconsistent formatting
5. ❌ Too long without enough value
