# Tweet Optimization Checklist

Use this checklist to evaluate and improve any tweet before posting. Each item is tied to a specific algorithm signal.

## Pre-Flight Checklist

### Hook Analysis (First 10 Words)

```
□ Does the first line stop the scroll?
□ Is there a pattern interrupt or curiosity gap?
□ Would you click "see more" if you saw only the first line?
□ Is there emotional resonance (not just information)?
□ Is it specific (numbers, names, outcomes)?
```

**Scoring:**
- 5/5: Excellent hook - high scroll-stop potential
- 3-4/5: Good hook - may need refinement
- 1-2/5: Weak hook - rewrite before posting

### Reply Optimization

```
□ Does the tweet invite response?
□ Is there a question (explicit or implied)?
□ Is there something to agree or disagree with?
□ Is there a gap for people to fill in?
□ Would you reply if you saw this tweet?
```

**Reply-Triggering Elements:**
- Direct question at the end
- Bold/contrarian claim
- "Am I the only one who..."
- "What would you do..."
- Incomplete thought that begs completion
- Controversial ranking or comparison

### Repost Optimization

```
□ Is this valuable enough to share with someone's audience?
□ Does sharing this make the sharer look good?
□ Is there a quotable line or insight?
□ Is the value clear without context?
□ Would you repost this yourself?
```

**Repost-Triggering Elements:**
- Framework or mental model
- Unique data or insight
- Contrarian take others want to amplify
- Resource or tool recommendation
- Inspiring story or transformation

### Share (DM) Optimization

```
□ Is there a specific person who needs to see this?
□ Does it solve a specific problem?
□ Is it "send this to your friend who..." worthy?
□ Would sharing this strengthen a relationship?
□ Is it conversation-starter material?
```

**DM-Share-Triggering Elements:**
- Practical tip for specific situation
- "This reminded me of you" content
- Tool/resource discovery
- Funny/relatable observation
- Important news in niche

### Dwell Time Optimization

```
□ Is the formatting easy to read?
□ Are there line breaks for breathing room?
□ Does the structure encourage full reading?
□ Is there a payoff that rewards reading to the end?
□ Is each sentence necessary?
```

**Dwell-Enhancing Elements:**
- Short paragraphs (1-2 sentences)
- Strategic line breaks
- Lists with breathing room
- Story arc that builds
- Payoff/punchline at the end

### Follow Optimization

```
□ Does this demonstrate unique expertise?
□ Would someone want more content like this?
□ Is your voice/personality evident?
□ Does this represent your content pillars?
□ Would this make someone check your profile?
```

**Follow-Triggering Elements:**
- Demonstrated expertise
- Unique perspective or framework
- Consistent quality signal
- Clear niche positioning
- Personality that resonates

## Negative Signal Avoidance

```
□ Could this trigger "Not Interested"?
□ Could this trigger blocks or mutes?
□ Is this potentially reportable content?
□ Am I alienating part of my audience?
□ Is this engagement bait without value?
```

**Red Flags to Remove:**
- Pure engagement bait ("Like if you agree!")
- Unnecessarily polarizing content
- Punching down or mean-spirited content
- Clickbait without payoff
- Spammy self-promotion

## Technical Optimization

### Character Count

```
□ Under 280 characters for maximum readability
□ If longer, using "See more" strategically
□ Not padding with unnecessary words
□ Not cutting off at awkward points
```

**Length Guidelines:**
- Single insight: 50-150 characters
- Observation + take: 150-250 characters
- Mini-story: 200-280 characters
- Thread hooks: 180-280 characters

### Media Inclusion

```
□ Would an image increase engagement?
□ Would a video be more effective?
□ If using media, is it high quality?
□ Does the media add value (not just decoration)?
□ Is the media accessible (alt text)?
```

**Media Decision Tree:**
- Data/stats → Chart or infographic
- Tutorial → Video or screenshot
- Story → Text often better
- Resource → Screenshot of key part
- Hot take → Text usually best

### Timing

```
□ Posting during peak hours for my audience?
□ Avoiding competition with major events?
□ Giving enough time for engagement before next post?
□ Considering timezone of primary audience?
```

**Timing Considerations:**
- B2B: 8-9 AM, 12-1 PM, 5-6 PM weekdays
- B2C: 12-1 PM, 7-9 PM, weekends included
- Global: Rotate times or target primary market
- Thread: Post when you can engage for 30+ minutes

## Final Optimization Pass

### Clarity Check

```
□ Could someone understand this without context?
□ Is there exactly one main point?
□ Are there any confusing phrases?
□ Would this make sense to a new follower?
```

### Tone Check

```
□ Does this sound like me?
□ Is the tone appropriate for my brand?
□ Am I being authentic (not performative)?
□ Would I be comfortable with this going viral?
```

### Value Check

```
□ What does the reader get from this?
□ Is the value immediately clear?
□ Would I find this valuable if someone else posted it?
□ Does this earn attention or demand it?
```

## Quick Optimization Framework

For rapid tweet improvement, use the SHIFT method:

**S** - Specificity: Add numbers, names, outcomes
**H** - Hook: Strengthen the first line
**I** - Interaction: Add reply trigger
**F** - Format: Improve readability
**T** - Trim: Cut unnecessary words

### SHIFT Example

Before:
```
Here's some good advice about productivity. You should focus on one thing at a time instead of multitasking. It really helps.
```

After SHIFT:
```
I increased my output by 40% with one change:

Single-tasking.

For 90 minutes, one task only. No tabs. No phone.

Most people think they're productive multitasking.

They're just busy.

What's your biggest productivity struggle?
```

Changes:
- **S**: Added "40%" and "90 minutes"
- **H**: Strong opening with specific result
- **I**: Ended with question
- **F**: Added line breaks, shortened sentences
- **T**: Cut filler phrases

## Score Sheet Template

Use this template to score tweets before posting:

```
TWEET SCORE SHEET

Hook Strength:        /10
Reply Potential:      /10
Repost Potential:     /10
DM-Share Potential:   /10
Dwell Time:           /10
Follow Potential:     /10
Negative Signal Risk: /10 (lower is better)

TOTAL:               /70

Scoring Guide:
60-70: Exceptional - high viral potential
50-59: Strong - good engagement expected
40-49: Average - consider optimization
30-39: Weak - significant improvement needed
<30:   Do not post - needs complete rewrite
```
