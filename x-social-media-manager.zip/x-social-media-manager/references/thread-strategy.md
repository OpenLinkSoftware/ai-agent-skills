# Thread Strategy for X

Threads are X's long-form content format. They dominate For You feeds because they generate multiple engagement signals per piece of content.

## Why Threads Win in the Algorithm

1. **Multiple dwell events**: Each tweet = new dwell opportunity
2. **Compounding engagement**: Likes/replies on any tweet boost the thread
3. **Share optimization**: Easy to share specific insights
4. **Follow trigger**: Demonstrated expertise earns follows

## Thread Architecture

### The 7-Part High-Performance Thread Structure

```
1/ [HOOK] - Pattern interrupt, curiosity gap, bold claim
   ↓
2/ [CONTEXT] - Why this matters, establish credibility  
   ↓
3/ [POINT 1] - First key insight with example
   ↓
4/ [POINT 2] - Second key insight with example
   ↓
5/ [POINT 3] - Third key insight with example
   ↓
6/ [ACTIONABLE TAKEAWAY] - What to do with this information
   ↓
7/ [CTA] - Engagement ask + value reminder
```

### Hook Tweet (Tweet 1)

The hook tweet is 80% of your thread's success. It must:

- Stop the scroll (pattern interrupt)
- Create curiosity (information gap)
- Promise value (clear benefit)
- Stand alone (makes sense without thread)

**Hook Templates for Threads:**

```
I spent [TIME] [DOING THING].

Here's what I learned (thread):

---

[NUMBER] [THINGS] that will [BENEFIT]:

A thread 🧵

---

The [TOPIC] playbook:

(Save this)

---

How [PERSON/COMPANY] [ACHIEVED THING]:

A breakdown 🧵

---

[CONTRARIAN STATEMENT]

Let me explain:

---

I've [CREDIBILITY STATEMENT].

Here's what most people miss about [TOPIC]:
```

### Context Tweet (Tweet 2)

Establish why this matters and why you're qualified to speak on it.

```
First, some context:

[WHY THIS MATTERS]
[YOUR CREDIBILITY]
[WHAT'S COMING]

---

Why should you care?

[STAKES/CONSEQUENCES]
[OPPORTUNITY/THREAT]

---

Before we dive in:

I've [CREDIBILITY]. This thread condenses [VALUE STATEMENT].
```

### Body Tweets (Tweets 3-5+)

Each body tweet should:

- Make ONE clear point
- Include a concrete example or proof
- Be valuable standalone (shareable)
- Flow logically from previous tweet

**Body Tweet Structure:**

```
[NUMBER]. [POINT HEADLINE]

[EXPLANATION - 1-2 sentences]

[EXAMPLE/PROOF]

---

[POINT]:

• [Sub-point 1]
• [Sub-point 2]  
• [Sub-point 3]

[EXAMPLE]

---

[POINT] →

[EXPLANATION]

Real example: [SPECIFIC CASE]
```

### Takeaway Tweet (Tweet 6)

Synthesize the thread into actionable next steps.

```
The takeaway:

[CORE INSIGHT]

[WHAT TO DO NEXT]

---

TL;DR:

• [Key point 1]
• [Key point 2]
• [Key point 3]

Start with [FIRST ACTION].

---

If you remember nothing else:

[SINGLE MOST IMPORTANT INSIGHT]
```

### CTA Tweet (Tweet 7)

Ask for engagement + remind of value + create follow incentive.

```
If this was helpful:

1. Follow @[HANDLE] for more [TOPIC]
2. RT the first tweet to help others
3. Reply with your biggest takeaway

---

That's a wrap!

♻️ Repost the first tweet to share this with your audience.

Follow @[HANDLE] for daily [TOPIC] insights.

---

Found this valuable?

• Follow for more threads like this
• Bookmark for later reference
• Share with someone who needs this
```

## Thread Engagement Tactics

### Embedded Engagement Triggers

Place these throughout the thread (not just at the end):

```
[After a key point]
(Which of these resonates most? Reply below)

---

[After controversial point]
Agree or disagree?

---

[After practical tip]
Save this one for later 📌

---

[After relatable point]
Raise your hand if this is you 🙋
```

### The "Reply Ladder" Technique

Structure body tweets to build on each other, so readers feel compelled to finish:

```
3/ The first thing you need to understand is [X]...

4/ Once you grasp that, you'll see why [Y]...

5/ And that's what makes [Z] so powerful...
```

### Self-Quoting for Reach

Quote-tweet your own thread with the best single insight:

```
The most underrated part of [TOPIC]:

[QUOTE BEST INSIGHT FROM THREAD]

Full thread below 👇
```

## Thread Length Guidelines

| Thread Type | Optimal Length | Use Case |
|-------------|---------------|----------|
| Quick Thread | 3-5 tweets | Single insight, quick tip |
| Standard Thread | 7-10 tweets | Framework, lesson, breakdown |
| Mega Thread | 15-25 tweets | Comprehensive guide, deep dive |
| Epic Thread | 30+ tweets | Ultimate guide, course-style |

**Rule of thumb**: Every tweet must earn its place. Cut ruthlessly.

## Thread Formatting Rules

### Visual Breaks

Use line breaks to increase readability and dwell time:

```
❌ Bad:
Here's the thing about growth. Most people focus on tactics but ignore strategy. The result is random acts of marketing.

✅ Good:
Here's the thing about growth:

Most people focus on tactics but ignore strategy.

The result?

Random acts of marketing.
```

### Numbering Formats

```
Standard: 1/ 2/ 3/

Alternative: 1. 2. 3.

Emoji: 1️⃣ 2️⃣ 3️⃣

Headers: [1/10] [2/10] [3/10]
```

### Emphasis Techniques

```
ALL CAPS for key phrases (sparingly)

→ Arrows for flow
↓ Down arrows for continuation

• Bullets for lists

"Quotes" for memorable phrases

*Asterisks* for emphasis (renders as italic on some clients)
```

## Thread Timing Strategy

### Best Days for Threads

1. **Tuesday** - High engagement, low competition
2. **Wednesday** - Peak professional activity
3. **Thursday** - Strong engagement continuation
4. **Sunday** - Casual browsing, high consumption

### Best Times for Threads (Adjust for Audience)

- **8-9 AM**: Morning commute/routine
- **12-1 PM**: Lunch break browsing
- **5-6 PM**: End of workday
- **8-9 PM**: Evening wind-down

### Thread Momentum

Post subsequent tweets quickly (15-30 seconds apart) to:
- Keep readers engaged
- Signal "active thread" to algorithm
- Prevent fragmented engagement

## Thread Repurposing

One thread can become:

1. **Blog post** - Expand each tweet into a paragraph
2. **Newsletter** - Add context and examples
3. **LinkedIn post** - Condense to single post + carousel
4. **Video script** - Each tweet = one talking point
5. **Lead magnet** - Expand into PDF guide
6. **Carousel** - Convert to image slides

## Common Thread Mistakes

| Mistake | Fix |
|---------|-----|
| Weak hook | Test 3-5 variations before posting |
| Too long without value | Cut anything that doesn't teach or prove |
| No examples | Every point needs proof |
| Buried CTA | Also place mini-CTAs mid-thread |
| Posted at bad time | Schedule for peak hours |
| No self-quote | Quote best insight 2-4 hours later |
| One and done | Engage with every reply |
