# Common Muted Patterns

Patterns, phrases, and behaviors that commonly get muted by users. The X algorithm's `MutedKeywordFilter` removes posts containing a user's muted keywords, so avoiding these patterns increases your potential reach.

## Why This Matters

When users mute keywords:
1. Your post is **completely filtered out** of their feed
2. You get **zero impressions** from that user
3. Mutes are **invisible** - you'll never know why reach dropped

The solution: Avoid patterns that trigger mass muting.

---

## Category 1: Engagement Bait Phrases

These phrases are so overused that many users auto-mute them.

### High-Risk Phrases (Widely Muted)

```
"Like if you agree"
"Retweet if..."
"RT if..."
"Share if you..."
"Comment [emoji] if..."
"Drop a [emoji] if..."
"Ratio"
"Let's get this to..."
"Can we get to X likes?"
"Help me reach..."
"This needs to go viral"
"Please retweet"
"Thread 🧵" (some mute this - use variations)
```

### Safer Alternatives

| Instead of | Try |
|------------|-----|
| "Like if you agree" | End with a question that invites replies |
| "Retweet if..." | "Share if you know someone who needs this" |
| "Comment emoji" | "What's your experience with this?" |
| "Thread 🧵" | "Here's what I learned:" or just start the thread |

---

## Category 2: Crypto/NFT/Web3 Terminology

Heavily muted by non-crypto users. If your audience isn't crypto-native, avoid:

```
"gm" (good morning - crypto Twitter greeting)
"wagmi" / "ngmi"
"lfg" (let's f***ing go)
"ser"
"anon"
"fren"
"probably nothing"
"wen" (when)
"alpha" (in the crypto context)
"degen"
"ape in"
"diamond hands" / "paper hands"
"to the moon" / "🚀"
"HODL"
"NFT" / "nft"
"web3"
"mint"
"airdrop"
"whitelist" / "allowlist"
```

### If You Must Discuss Crypto

- Spell out terms professionally
- Use standard English
- Avoid insider slang

---

## Category 3: Political/Culture War Terms

Extremely polarizing terms often get muted by one side or the other, limiting reach:

```
[Political figure names]
"woke"
"based"
"red pill" / "blue pill"
"libtard" / "conservatard"
"snowflake"
"triggered"
"cancel culture" / "cancelled"
"virtue signal"
[Current hot-button issue keywords]
```

### Best Practice

Unless politics IS your niche:
- Avoid partisan framing
- Focus on ideas over identities
- Stay in your lane

---

## Category 4: MLM/Hustle Culture Clichés

Overused "entrepreneur" phrases that signal spam:

```
"passive income"
"financial freedom"
"6 figures" / "7 figures"
"make money while you sleep"
"boss babe"
"work from anywhere"
"fire your boss"
"laptop lifestyle"
"location independent"
"DM me for details"
"link in bio" (some mute this)
"secret" / "secrets"
"they don't want you to know"
"unlock"
"exclusive"
"limited spots"
```

### Safer Alternatives

| Instead of | Try |
|------------|-----|
| "6 figures" | Specific numbers or "sustainable income" |
| "passive income" | "recurring revenue" or describe the actual model |
| "DM me" | Provide value first, let them come to you |
| "secrets" | "lessons" / "insights" / "what I learned" |

---

## Category 5: Spam Patterns

Behaviors/patterns that resemble spam bots:

```
• Excessive hashtags (more than 2-3)
• ALL CAPS sentences
• Repeated emojis (🔥🔥🔥🔥🔥)
• Multiple exclamation points!!!
• Starting with "BREAKING:"
• Starting with "HUGE:"
• "YOU NEED TO SEE THIS"
• Chain letter patterns ("repost or...")
• Identical reply to multiple accounts
• Posting same content repeatedly
```

### Guidelines

- Maximum 2-3 hashtags (or none)
- One emoji type per tweet
- Professional punctuation
- Each post should be unique

---

## Category 6: Engagement Farming Patterns

Recognized patterns that savvy users mute:

```
"Unpopular opinion:" (becoming overused)
"Hot take:"
"Controversial opinion:"
"Let that sink in."
"Read that again."
"This."
"Louder for the people in the back"
"I'll say it again"
"Facts."
"Period."
"No cap"
"IYKYK"
"Say it louder"
```

### The Problem

These phrases:
1. Signal low-effort content
2. Feel manipulative
3. Are associated with engagement farming

### Better Approach

Just make your point. If it's unpopular or controversial, the content will show that—you don't need to announce it.

---

## Category 7: Rage Bait Indicators

Content designed to make people angry:

```
"[Group] are the worst"
"Imagine being someone who..."
"Tell me you're X without telling me"
"The audacity of..."
"I'm so sick of..."
"Why do people..."
"People who [do X] are..."
"Nobody asked but..."
```

### Why It's Muted

- Creates negative feed experience
- Users learn to mute outrage content
- Attracts wrong type of engagement

---

## Category 8: Self-Promotional Spam

Patterns that signal aggressive promotion:

```
"Buy now"
"Limited time"
"Act fast"
"Don't miss out"
"Sale ends"
"Click here"
"Sign up"
"Subscribe"
"Use code"
"Discount"
"Free [thing] if you..."
"Giveaway" (heavily muted)
"Contest"
```

### Promotional Best Practices

- Limit promotional posts to 15% of content
- Lead with value, not asks
- Make promotions conversational, not salesy
- Use soft CTAs: "Check it out if interested"

---

## Category 9: Bot/Scam Indicators

Phrases associated with bots and scams:

```
"Congratulations! You won..."
"DM to claim"
"I made $X in Y days"
"Easy money"
"Free [expensive thing]"
"100% guaranteed"
"No risk"
"Double your..."
"Investment opportunity"
"Too good to be true" (ironic but still flagged)
```

---

## Category 10: Overused Formats

Formats so common they've been muted by format-fatigued users:

```
"Nobody:
Literally nobody:
[Thing]:"

"Me: [action]
Also me: [contradicting action]"

"[Thing] walked so [other thing] could run"

"[Year] [Person]: [Quote]
[Later year] [Same person]: [Contradicting quote]"

"Wrong answers only"

"Name a better [thing]. I'll wait."

"We need to talk about [thing]"
```

### Guidance

These formats CAN work if:
- The content is genuinely funny/insightful
- You add a twist
- You're early to a trend

But they're risky for reach.

---

## Testing Your Content

### Pre-Post Checklist

1. [ ] No phrases from "High-Risk" lists
2. [ ] No excessive hashtags (>3)
3. [ ] No ALL CAPS sentences
4. [ ] No emoji spam
5. [ ] No aggressive CTAs
6. [ ] Unique content (not copied/repeated)
7. [ ] No insider jargon (unless audience expects it)
8. [ ] No rage bait framing

### If You Must Use Risky Phrases

- **Crypto terms**: Only if audience is crypto-native
- **Political terms**: Only if politics is your explicit niche
- **Promotional terms**: Sparingly, with high-value content

---

## Regional/Niche Mute Patterns

Some communities have specific mute patterns:

### Tech Twitter
```
"Founder mode"
"10x engineer"
"Hustle"
"Grind"
```

### Media Twitter
```
"BREAKING"
"Developing"
"Sources say"
```

### Sports Twitter
```
"Ratio"
"Clear of"
"Poverty franchise"
```

### Know Your Audience

Research what YOUR specific audience tends to mute by:
1. Observing what successful accounts in your niche avoid
2. Asking your audience directly
3. Testing content with and without certain phrases
