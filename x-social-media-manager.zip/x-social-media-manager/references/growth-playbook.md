# X Growth Playbook

Comprehensive strategies for growing your X following organically, aligned with algorithm mechanics.

## Understanding Growth on X

Growth happens through three mechanisms:

1. **In-Network Amplification**: Followers engage → shown to their followers
2. **Out-of-Network Discovery**: Phoenix retrieval finds you for new users
3. **Profile Conversions**: Visitors → Followers

All three must work together for sustainable growth.

---

## Phase 1: Foundation (0-1,000 Followers)

### Mindset

At this stage, you don't have distribution. Every post reaches very few people. Your job is to:
1. Find your voice
2. Build initial momentum
3. Create "lighthouse content" that attracts early followers

### Strategy 1: Strategic Replying (Most Important)

Replying to larger accounts is your primary growth lever.

**The math:**
- Your tweet reaches ~50 people (your followers)
- Your reply on a 100K account's viral post reaches ~50,000 people
- That's 1000x the eyeballs

**How to do it well:**

1. **Identify target accounts**
   - In your niche
   - Active (posts 2+ times daily)
   - Engaging with replies
   - 10K-500K followers (sweet spot)

2. **Turn on notifications** for these accounts

3. **Reply within 5-15 minutes** of their posts (early replies get seen)

4. **Add value** with every reply:
   - Personal experience related to their point
   - Specific example or data
   - Thoughtful question
   - Contrasting perspective (respectfully)

5. **Never say:**
   - "Great point!"
   - "This 💯"
   - "So true"
   - Anything that's just agreement without substance

**Template replies that work:**

```
[Agree + Add]:
"This matches my experience. When I [specific example], 
I found that [insight]. The part most people miss is [addition]."

[Respectful challenge]:
"Interesting take. I've seen this work for [context], but 
wondered if [alternative] might be better for [other context]? 
What's your experience?"

[Question that shows expertise]:
"Love this. How do you handle [specific edge case]? I've been 
experimenting with [your approach] but curious about your take."
```

### Strategy 2: Consistent Posting

Even with small reach, you need content for profile visitors to evaluate.

**Minimum viable posting:**
- 1 post per day
- Same time each day (build habit)
- Mix of formats (see tweet-formats.md)

**What to post when no one's watching:**

1. **Document your journey**: "Day 1 of learning X..."
2. **Share your process**: "Here's how I approach [problem]..."
3. **React to industry news**: "Thoughts on [event]..."
4. **Curate value**: "Best [resources] I've found for [topic]..."

### Strategy 3: Profile Optimization

When someone visits your profile from a reply, you have 3 seconds to convert them.

**Bio formula:**
```
[Who you are] + [What you do/share] + [Credibility marker or personality]

Example:
"Product designer at [Company]. Writing about UX, design systems, 
and building products people love. Previously designed [notable thing]."
```

**Pinned tweet:**
- Should be your single best piece of content
- Or a thread that demonstrates expertise
- Update monthly with your best performer

**Profile picture:**
- Clear face photo (builds trust)
- Good lighting
- Consistent across platforms

---

## Phase 2: Momentum (1,000-10,000 Followers)

### Mindset

You have enough distribution for content to get tested. Now focus on:
1. Finding what resonates
2. Developing signature content types
3. Building engagement habits with your audience

### Strategy 1: Engagement Reciprocity

Your followers are now an asset. Treat them that way.

**Daily engagement routine:**
1. Reply to EVERY comment on your posts (first 2 hours crucial)
2. Like comments even if you don't reply
3. Visit profiles of consistent engagers
4. DM thank-you to new engaged followers (sparingly)

**Why this matters:**
- Algorithm sees you driving conversation
- Commenters become repeat engagers
- Builds genuine community

### Strategy 2: Content Experimentation

Find your "hit formats" through systematic testing.

**Testing framework:**

| Week | Focus | Formats to Test |
|------|-------|-----------------|
| 1 | Hook styles | Question, Statement, Story |
| 2 | Content types | Tips, Observations, Hot takes |
| 3 | Length | Short (1-2 lines), Medium, Thread |
| 4 | Timing | Morning, Afternoon, Evening |

**Track what works:**
- Impressions (reach)
- Engagement rate (quality)
- Profile visits (conversion interest)
- Follower gain (actual growth)

### Strategy 3: Collaboration

Leverage other growing accounts in your niche.

**Methods:**
1. **Quote tweet exchanges**: Quote their content, they quote yours
2. **Thread collaborations**: Co-create a thread
3. **Shoutout circles**: Groups that amplify each other (use sparingly)
4. **Cross-promotion**: Recommend each other to audiences

**Finding collaborators:**
- Look for accounts at similar size (500-2x your followers)
- Same niche, complementary perspectives
- Active and genuine (not engagement farmers)

---

## Phase 3: Scale (10,000-100,000 Followers)

### Mindset

You have real distribution. Content quality and consistency become paramount. Focus on:
1. Systemizing content creation
2. Building "content flywheels"
3. Converting audience to deeper engagement

### Strategy 1: Content Systems

Sustainable growth requires sustainable content creation.

**Content pillar system:**

Pick 3-5 themes you'll consistently cover:

```
Example for a startup founder:
1. Startup lessons (40%)
2. Leadership/management (25%)
3. Industry analysis (20%)
4. Personal journey (15%)
```

**Batching workflow:**

1. **Ideation day** (monthly): Generate 30+ ideas
2. **Writing blocks** (weekly): Draft week's content
3. **Scheduling** (weekly): Queue posts at optimal times
4. **Engagement windows** (daily): Respond to comments

### Strategy 2: Flywheel Content

Create content that generates more content.

**The flywheel:**
```
Observation → Tweet → Engagement → Replies give more ideas → New content
```

**Flywheel formats:**
1. "What's your take on X?" → Use best replies in follow-up thread
2. "Mistakes I've made in [field]" → Each reply is a new topic
3. "AMA about [expertise]" → Questions become content

### Strategy 3: Platform Diversification

Use your X audience to build on other platforms.

**Newsletter synergy:**
- Promote newsletter in bio/pinned
- Repurpose best tweets into newsletter
- Preview newsletter content on X

**LinkedIn synergy:**
- Reformat threads for LinkedIn
- Different algorithm, same content
- Cross-pollinate audiences

**YouTube/Podcast synergy:**
- Use X for topic validation
- Announce new content
- Clip key moments for X

---

## Phase 4: Authority (100,000+ Followers)

### Mindset

You're a recognized voice. Now focus on:
1. Maintaining quality at scale
2. Building lasting influence
3. Monetizing appropriately

### Strategy 1: Quality Over Quantity

At scale, bad content hurts more than no content.

**Quality guidelines:**
- Reduce to 1-2 high-quality posts per day
- Invest more time per post
- Say no to easy engagement bait
- Maintain your unique voice

### Strategy 2: Community Building

Move from audience to community.

**Methods:**
- Host Twitter Spaces regularly
- Create exclusive content for engaged followers
- Build off-platform community (Discord, etc.)
- Meet top engagers IRL

### Strategy 3: Monetization (If Desired)

Appropriate at this level:
- Sponsored content (clearly disclosed)
- Products/services promotion
- Premium content offerings
- Consulting/advisory

---

## Growth Tactics (All Phases)

### Tactical Lever 1: Optimal Posting Times

Post when your audience is active.

**General high-engagement windows (US-centric):**
- Weekdays: 8-10 AM, 12-1 PM, 5-7 PM ET
- Weekends: 9-11 AM ET

**Finding YOUR optimal times:**
1. Check Analytics → Posts → sort by impressions
2. Note times of top performers
3. Test different times for 2 weeks
4. Settle on 2-3 optimal windows

### Tactical Lever 2: Hashtag Strategy

Hashtags are controversial. Current best practice:

**Do:**
- Use 0-2 hashtags per post
- Only for genuinely relevant, active tags
- Place at end of post or in reply

**Don't:**
- Use more than 3 hashtags
- Use generic tags (#success #motivation)
- Let hashtags interrupt readability

### Tactical Lever 3: Visual Content

Images and videos get more engagement—but only if good.

**When to use images:**
- Screenshots of data/results
- Diagrams explaining concepts
- Behind-the-scenes photos
- Memes (if fits your brand)

**When to use video:**
- Personal updates/announcements
- Demonstrations
- Quick tips (under 60 seconds)
- Repurposed long-form content

### Tactical Lever 4: Threads for Growth

Threads are growth accelerators when done well.

**Thread growth formula:**
1. **Hook** must be strong enough to stand alone
2. **Promise** clear value early
3. **Deliver** real insights (not fluff)
4. **CTA** on final tweet (follow + repost)

**Thread promotion:**
- Reply to your own thread with bonus content
- Quote tweet thread opener 24-48 hours later
- Pin top-performing threads to profile

---

## Common Growth Mistakes

### Mistake 1: Engagement Farming

Buying followers, joining engagement pods, using growth hacks.

**Why it fails:**
- Fake engagement doesn't translate to real reach
- Algorithm detects inauthentic patterns
- Kills your reputation when discovered

### Mistake 2: Inconsistency

Posting heavily for a week, then disappearing.

**Why it fails:**
- Algorithm rewards consistency
- Audience forgets you
- Momentum lost

### Mistake 3: Wrong Metrics

Chasing follower count over engagement rate.

**Why it fails:**
- 100K followers with 0.1% engagement is worthless
- 10K followers with 5% engagement is powerful
- Engagement rate determines reach

### Mistake 4: No Niche

Posting about everything to everyone.

**Why it fails:**
- Algorithm can't categorize your content
- Audience doesn't know what to expect
- No discovery via semantic similarity

### Mistake 5: All Value, No Personality

Being a "content machine" without human elements.

**Why it fails:**
- People follow people, not content
- No emotional connection = easy unfollow
- Misses the "follow author" signal

---

## Growth Benchmarks

| Follower Range | Good Monthly Growth | Great Monthly Growth |
|----------------|---------------------|----------------------|
| 0-1K | +100-200 | +300-500 |
| 1K-10K | +500-1K | +1K-2K |
| 10K-50K | +1K-3K | +3K-5K |
| 50K-100K | +2K-5K | +5K-10K |
| 100K+ | +5K-10K | +10K-20K |

**Note:** Quality of followers matters more than quantity. High-engagement followers from your niche > random followers.

---

## Quick Reference: Daily Growth Routine

### 15-Minute Routine (Minimum Viable)
1. Post 1 piece of content (pre-written ideally)
2. Reply to 3-5 larger accounts in niche
3. Respond to comments on your posts

### 45-Minute Routine (Recommended)
1. Morning: Post content, engage with comments
2. Midday: Reply to 5-10 accounts, check notifications
3. Evening: Second post, engagement round

### 90-Minute Routine (Growth Mode)
1. Create 1-2 pieces of original content
2. 20+ strategic replies
3. Full comment engagement
4. DM conversations with key connections
5. Profile optimization check
