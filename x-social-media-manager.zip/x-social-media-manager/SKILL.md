---
name: x-social-media-manager
description: Expert X (Twitter) social media management based on reverse-engineered algorithm insights. Use this skill when users need help with writing optimized tweets, developing posting strategies, analyzing tweet performance, growing followers, understanding X algorithm mechanics, creating content calendars, optimizing engagement, writing replies, building audience relationships, or any X/Twitter content creation task.
---

# X Social Media Manager

Expert social media management for X (Twitter) based on deep analysis of the recommendation algorithm.

## Algorithm Foundation

The X "For You" feed uses a two-stage ML pipeline:

1. **Retrieval**: Finds candidate posts via in-network (Thunder) and out-of-network (Phoenix) sources
2. **Ranking**: Grok-based transformer predicts engagement probabilities, weighted into final scores

### Engagement Weights (Ranked by Impact)

| Engagement Type | Weight Class | Strategy Implication |
|-----------------|--------------|----------------------|
| Replies | HIGH+ | Create conversation starters |
| Reposts | HIGH+ | Make content share-worthy |
| Quotes | HIGH | Encourage quote-tweeting |
| Likes | HIGH | Baseline engagement |
| Shares (DM/Copy Link) | HIGH | Create "send to a friend" content |
| Profile Clicks | MEDIUM | Build curiosity about author |
| Dwell Time | MEDIUM | Write content worth reading slowly |
| Video Quality Views | MEDIUM | Videos >threshold duration get bonus |
| Follow Author | STRONG+ | Convert viewers to followers |
| Photo Expand | LOW | Use compelling images |

### Negative Signals (Penalize Ranking)

| Signal | Impact | Avoidance Strategy |
|--------|--------|-------------------|
| Block | SEVERE | Never harass or spam |
| Mute | SEVERE | Avoid repetitive patterns |
| Report | SEVERE | Stay within guidelines |
| "Not Interested" | HIGH | Match audience expectations |

### Key Algorithm Behaviors

1. **In-Network Boost**: Posts from followed accounts get priority over out-of-network discovery
2. **Author Diversity Penalty**: Multiple posts from same author in one session get decaying scores
3. **Freshness Filter**: Posts older than threshold are removed entirely
4. **Engagement History**: Model uses 128 items of user history to predict preferences

## Tweet Writing Workflow

### Step 1: Define Objective

Determine primary goal:
- **Engagement**: Maximize replies/reposts
- **Growth**: Optimize for follows
- **Traffic**: Drive clicks to external content
- **Authority**: Build thought leadership
- **Community**: Foster conversation

### Step 2: Select Format

Choose based on objective. See `references/tweet-formats.md` for detailed templates.

| Format | Best For | Engagement Type |
|--------|----------|-----------------|
| Hook + Insight | Authority | Dwell, Likes |
| Question | Community | Replies |
| Thread | Deep content | Dwell, Reposts |
| Hot Take | Virality | Quotes, Replies |
| List/Tips | Utility | Reposts, Saves |
| Story | Connection | Replies, Follows |

### Step 3: Apply Algorithm Optimization

For every tweet, verify:

1. **Reply Magnet**: Does it invite responses? Add opinion gaps, questions, or incomplete thoughts
2. **Repost Trigger**: Is it valuable enough to share? Add utility, humor, or strong POV
3. **Quote Bait**: Does it warrant addition? Make it a conversation starter
4. **Dwell Optimization**: Is it worth reading carefully? Add depth without padding
5. **Share Catalyst**: Would someone DM this to a friend? Add relatability or insider value

### Step 4: Quality Check

Run through `scripts/tweet_analyzer.py` or manually verify:
- [ ] No muted-keyword patterns (see `references/common-muted-patterns.md`)
- [ ] Appropriate length for format
- [ ] Clear value proposition in first line
- [ ] No engagement bait that triggers "not interested"
- [ ] Matches audience's demonstrated interests

## Content Strategy

### Posting Frequency

The author diversity scorer penalizes rapid consecutive posts. Optimal patterns:

- **Maximum**: 3-5 quality posts per day, spaced 3+ hours apart
- **Minimum**: 1 post per day for consistency
- **Threads**: Count as single post, use for longer content

### Timing Strategy

Post when your audience is active. Use `scripts/optimal_timing.py` with audience timezone data.

General high-engagement windows (US-centric):
- Weekdays: 8-10 AM, 12-1 PM, 5-7 PM
- Weekends: 9-11 AM

### Content Mix

Balance content types weekly:

| Type | Percentage | Purpose |
|------|------------|---------|
| Value/Educational | 40% | Build authority |
| Engagement/Questions | 25% | Drive replies |
| Personal/Story | 20% | Build connection |
| Promotional | 15% | Convert to goals |

## Thread Writing

Threads get special treatment—they're a single unit that can accumulate engagement across multiple posts.

### Thread Structure

```
Tweet 1: Hook (most critical—must stop the scroll)
Tweet 2: Promise/Setup (what reader will learn)
Tweet 3-N: Value delivery (one point per tweet)
Final Tweet: Summary + CTA
```

See `references/thread-templates.md` for proven structures.

## Reply Strategy

Replies are high-signal engagement. Strategic replying:

1. **Target accounts** your audience follows (builds in-network presence)
2. **Add value**, don't just agree (earns profile clicks → follows)
3. **Reply early** to high-engagement accounts (visibility boost)
4. **Use the conversation** to demonstrate expertise

## Analytics Interpretation

When analyzing tweet performance:

| Metric | Algorithm Signal | Action if Low |
|--------|------------------|---------------|
| Impressions | Retrieval success | Improve hooks, check timing |
| Engagement Rate | Ranking score | Better CTAs, stronger opinions |
| Reply Ratio | Conversation quality | Add questions, opinion gaps |
| Repost Ratio | Share value | Increase utility/novelty |
| Profile Visits | Curiosity generated | Strengthen author intrigue |
| Follow Rate | Conversion | Improve bio, pinned tweet |

## Quick Reference

### High-Impact Patterns

1. **"Unpopular opinion:"** — Drives quotes and replies
2. **"Most people don't know:"** — Drives reposts and saves  
3. **"Here's what I learned:"** — Drives dwell and follows
4. **"Quick thread:"** — Signals digestible value
5. **Open question** — Drives replies

### Avoid These

1. Engagement bait ("Like if you agree")
2. Repetitive hashtag spam
3. Posting identical content
4. Aggressive self-promotion
5. Combative replies
6. Content that typically gets muted (see references)

## Files Reference

- `references/tweet-formats.md` — Detailed templates for every tweet type
- `references/thread-templates.md` — Proven thread structures
- `references/common-muted-patterns.md` — Patterns to avoid
- `references/algorithm-deep-dive.md` — Full technical algorithm details
- `references/growth-playbook.md` — Follower growth strategies
- `scripts/tweet_analyzer.py` — Analyze tweet optimization
- `scripts/optimal_timing.py` — Calculate best posting times
- `scripts/content_calendar.py` — Generate content calendars
- `assets/content-calendar-template.md` — Weekly planning template
