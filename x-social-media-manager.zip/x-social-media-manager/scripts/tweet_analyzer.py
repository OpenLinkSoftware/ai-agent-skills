#!/usr/bin/env python3
"""
Tweet Analyzer - Analyze tweets for algorithm optimization.

Evaluates tweets against X algorithm insights to predict engagement potential
and provide optimization suggestions.

Usage:
    python tweet_analyzer.py "Your tweet text here"
    python tweet_analyzer.py --file tweets.txt
    python tweet_analyzer.py --interactive
"""

import argparse
import re
import json
from dataclasses import dataclass, field
from typing import List, Dict, Tuple
from enum import Enum


class EngagementType(Enum):
    REPLY = "reply"
    REPOST = "repost"
    LIKE = "like"
    QUOTE = "quote"
    DWELL = "dwell"
    PROFILE_CLICK = "profile_click"
    SHARE = "share"


@dataclass
class AnalysisResult:
    score: int  # 0-100
    engagement_potential: Dict[EngagementType, str]
    strengths: List[str]
    weaknesses: List[str]
    suggestions: List[str]
    warnings: List[str]
    muted_pattern_matches: List[str]


# Commonly muted patterns
MUTED_PATTERNS = {
    "engagement_bait": [
        r"\blike if you agree\b",
        r"\bretweet if\b",
        r"\brt if\b",
        r"\bshare if you\b",
        r"\bcomment .{0,10} if\b",
        r"\bdrop a .{0,5} if\b",
        r"\bratio\b",
        r"\blet's get this to\b",
        r"\bhelp me reach\b",
        r"\bthis needs to go viral\b",
    ],
    "crypto_slang": [
        r"\bgm\b(?!\s*[A-Z])",  # gm but not GM (General Motors)
        r"\bwagmi\b",
        r"\bngmi\b",
        r"\blfg\b",
        r"\bdegen\b",
        r"\bhodl\b",
        r"\bto the moon\b",
        r"\bape in\b",
    ],
    "spam_patterns": [
        r"#{4,}",  # 4+ hashtags
        r"[!]{3,}",  # Multiple exclamation points
        r"(.)\1{4,}",  # Repeated characters
        r"^BREAKING:",
        r"^HUGE:",
        r"\bYOU NEED TO SEE THIS\b",
    ],
    "overused_formats": [
        r"^nobody:\s*\n",
        r"\bread that again\b",
        r"\blet that sink in\b",
        r"\blouder for the people in the back\b",
    ]
}

# Patterns that drive specific engagement
ENGAGEMENT_PATTERNS = {
    EngagementType.REPLY: [
        (r"\?$", "Ends with question"),
        (r"\bwhat do you think\b", "Asks for opinion"),
        (r"\bwhat's your\b", "Personal question"),
        (r"\bagree or disagree\b", "Binary choice"),
        (r"\bam i wrong\b", "Invites challenge"),
        (r"\bchange my mind\b", "Debate invitation"),
    ],
    EngagementType.REPOST: [
        (r"\b\d+\s*(tips|lessons|things|ways|rules)\b", "Listicle format"),
        (r"\bthread\b", "Thread signal"),
        (r"\bbookmark this\b", "Save prompt"),
        (r"\bsave this\b", "Save prompt"),
        (r"\bhere's how\b", "How-to content"),
    ],
    EngagementType.QUOTE: [
        (r"\bunpopular opinion\b", "Contrarian setup"),
        (r"\bhot take\b", "Hot take signal"),
        (r"\bcontroversial\b", "Controversy signal"),
        (r"\bi disagree\b", "Disagreement"),
    ],
    EngagementType.DWELL: [
        (r"\n.*\n.*\n", "Multi-line format"),
        (r".{200,}", "Long form content"),
        (r"\b(first|then|finally|1\.|2\.|3\.)", "Sequential content"),
    ],
}

# Positive patterns
POSITIVE_PATTERNS = [
    (r"^[A-Z][^.!?]*[.!?]$", "Clean single sentence", 5),
    (r"\n\n", "Good paragraph spacing", 3),
    (r"[\u2022\u2023\u25E6•]", "Bullet points for readability", 2),
    (r"\b(learned|realized|discovered)\b", "Personal insight language", 3),
    (r"\bhere's (what|how|why)\b", "Value promise", 4),
]

# Negative patterns
NEGATIVE_PATTERNS = [
    (r"https?://\S+", "Contains link (may reduce reach)", -2),
    (r"@\w+\s@\w+\s@\w+", "Multiple mentions (spam signal)", -5),
    (r"^.{0,30}$", "Very short tweet (low dwell time)", -3),
    (r"[A-Z]{10,}", "Excessive caps (spam signal)", -5),
    (r"(.)\1{3,}", "Character repetition", -3),
]


def check_muted_patterns(tweet: str) -> List[str]:
    """Check for commonly muted patterns."""
    matches = []
    tweet_lower = tweet.lower()
    
    for category, patterns in MUTED_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, tweet_lower, re.IGNORECASE):
                matches.append(f"{category}: {pattern}")
    
    return matches


def analyze_engagement_potential(tweet: str) -> Dict[EngagementType, Tuple[str, List[str]]]:
    """Analyze which engagement types the tweet is optimized for."""
    results = {}
    
    for eng_type, patterns in ENGAGEMENT_PATTERNS.items():
        matches = []
        for pattern, description in patterns:
            if re.search(pattern, tweet, re.IGNORECASE):
                matches.append(description)
        
        if len(matches) >= 2:
            level = "HIGH"
        elif len(matches) == 1:
            level = "MEDIUM"
        else:
            level = "LOW"
        
        results[eng_type] = (level, matches)
    
    return results


def calculate_score(tweet: str, muted_matches: List[str], engagement: Dict) -> Tuple[int, List[str], List[str]]:
    """Calculate overall optimization score."""
    score = 50  # Start at neutral
    strengths = []
    weaknesses = []
    
    # Muted patterns are severe penalties
    if muted_matches:
        score -= len(muted_matches) * 10
        weaknesses.append(f"Contains {len(muted_matches)} muted pattern(s)")
    
    # Check positive patterns
    for pattern, description, points in POSITIVE_PATTERNS:
        if re.search(pattern, tweet):
            score += points
            strengths.append(description)
    
    # Check negative patterns
    for pattern, description, points in NEGATIVE_PATTERNS:
        if re.search(pattern, tweet):
            score += points  # points are already negative
            weaknesses.append(description)
    
    # Engagement optimization bonus
    high_engagement_count = sum(1 for v in engagement.values() if v[0] == "HIGH")
    medium_engagement_count = sum(1 for v in engagement.values() if v[0] == "MEDIUM")
    
    score += high_engagement_count * 8
    score += medium_engagement_count * 3
    
    if high_engagement_count > 0:
        strengths.append(f"Optimized for {high_engagement_count} high-value engagement type(s)")
    
    # Length optimization
    length = len(tweet)
    if 100 <= length <= 200:
        score += 5
        strengths.append("Optimal length for engagement")
    elif length < 50:
        weaknesses.append("Too short for meaningful engagement")
    elif length > 270:
        strengths.append("Long-form content (good for dwell time)")
    
    # Cap score
    score = max(0, min(100, score))
    
    return score, strengths, weaknesses


def generate_suggestions(tweet: str, analysis: Dict, weaknesses: List[str]) -> List[str]:
    """Generate specific improvement suggestions."""
    suggestions = []
    
    # Check for missing engagement drivers
    if analysis[EngagementType.REPLY][0] == "LOW":
        suggestions.append("Add a question or invitation for response to drive replies")
    
    if analysis[EngagementType.REPOST][0] == "LOW":
        suggestions.append("Consider adding practical value or making it a list/thread for reposts")
    
    if analysis[EngagementType.DWELL][0] == "LOW" and len(tweet) < 150:
        suggestions.append("Expand content with more detail to increase dwell time")
    
    # Hook analysis
    first_line = tweet.split('\n')[0] if '\n' in tweet else tweet[:50]
    if not any(c in first_line for c in ['?', '!', ':']):
        suggestions.append("Strengthen your hook - first line should create curiosity")
    
    # CTA check
    if not re.search(r'\?|reply|share|comment|follow|thoughts', tweet, re.IGNORECASE):
        suggestions.append("Add a call-to-action to direct engagement")
    
    return suggestions


def analyze_tweet(tweet: str) -> AnalysisResult:
    """Main analysis function."""
    
    # Check for muted patterns
    muted_matches = check_muted_patterns(tweet)
    
    # Analyze engagement potential
    engagement = analyze_engagement_potential(tweet)
    
    # Calculate score
    score, strengths, weaknesses = calculate_score(tweet, muted_matches, engagement)
    
    # Generate suggestions
    suggestions = generate_suggestions(tweet, engagement, weaknesses)
    
    # Generate warnings
    warnings = []
    if muted_matches:
        warnings.append("⚠️ Tweet contains patterns commonly muted by users")
    if score < 40:
        warnings.append("⚠️ Low optimization score - consider significant revisions")
    
    # Format engagement potential
    engagement_formatted = {
        eng_type: f"{level} ({', '.join(reasons) if reasons else 'no specific signals'})"
        for eng_type, (level, reasons) in engagement.items()
    }
    
    return AnalysisResult(
        score=score,
        engagement_potential=engagement_formatted,
        strengths=strengths,
        weaknesses=weaknesses,
        suggestions=suggestions,
        warnings=warnings,
        muted_pattern_matches=muted_matches
    )


def format_result(result: AnalysisResult, tweet: str) -> str:
    """Format analysis result for display."""
    output = []
    output.append("=" * 60)
    output.append("TWEET ANALYSIS REPORT")
    output.append("=" * 60)
    output.append(f"\nTweet: \"{tweet[:100]}{'...' if len(tweet) > 100 else ''}\"")
    output.append(f"Characters: {len(tweet)}/280")
    
    output.append(f"\n{'─' * 40}")
    output.append(f"OPTIMIZATION SCORE: {result.score}/100")
    output.append(f"{'─' * 40}")
    
    if result.score >= 70:
        output.append("✅ Well optimized for the algorithm")
    elif result.score >= 50:
        output.append("🔶 Moderately optimized - room for improvement")
    else:
        output.append("🔴 Needs significant optimization")
    
    if result.warnings:
        output.append(f"\n{'─' * 40}")
        output.append("WARNINGS:")
        for warning in result.warnings:
            output.append(f"  {warning}")
    
    output.append(f"\n{'─' * 40}")
    output.append("ENGAGEMENT POTENTIAL:")
    for eng_type, potential in result.engagement_potential.items():
        emoji = "🟢" if "HIGH" in potential else "🟡" if "MEDIUM" in potential else "⚪"
        output.append(f"  {emoji} {eng_type.value.upper()}: {potential}")
    
    if result.strengths:
        output.append(f"\n{'─' * 40}")
        output.append("STRENGTHS:")
        for strength in result.strengths:
            output.append(f"  ✓ {strength}")
    
    if result.weaknesses:
        output.append(f"\n{'─' * 40}")
        output.append("WEAKNESSES:")
        for weakness in result.weaknesses:
            output.append(f"  ✗ {weakness}")
    
    if result.suggestions:
        output.append(f"\n{'─' * 40}")
        output.append("SUGGESTIONS:")
        for i, suggestion in enumerate(result.suggestions, 1):
            output.append(f"  {i}. {suggestion}")
    
    if result.muted_pattern_matches:
        output.append(f"\n{'─' * 40}")
        output.append("MUTED PATTERNS DETECTED:")
        for match in result.muted_pattern_matches:
            output.append(f"  ⚠️ {match}")
    
    output.append("\n" + "=" * 60)
    
    return "\n".join(output)


def interactive_mode():
    """Run in interactive mode."""
    print("\n🐦 Tweet Analyzer - Interactive Mode")
    print("Type 'quit' to exit, 'help' for tips\n")
    
    while True:
        print("-" * 40)
        tweet = input("Enter tweet to analyze:\n> ")
        
        if tweet.lower() == 'quit':
            print("Goodbye!")
            break
        elif tweet.lower() == 'help':
            print("""
Tips for high-scoring tweets:
- End with a question to drive replies
- Use lists or "how-to" format for reposts
- Add line breaks for readability
- Avoid engagement bait phrases
- Keep between 100-200 characters for optimal engagement
- Include a clear value proposition in the first line
            """)
            continue
        elif not tweet.strip():
            continue
        
        result = analyze_tweet(tweet)
        print(format_result(result, tweet))


def main():
    parser = argparse.ArgumentParser(
        description="Analyze tweets for X algorithm optimization"
    )
    parser.add_argument(
        "tweet",
        nargs="?",
        help="Tweet text to analyze"
    )
    parser.add_argument(
        "--file", "-f",
        help="File containing tweets (one per line)"
    )
    parser.add_argument(
        "--interactive", "-i",
        action="store_true",
        help="Run in interactive mode"
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        help="Output results as JSON"
    )
    
    args = parser.parse_args()
    
    if args.interactive:
        interactive_mode()
    elif args.file:
        with open(args.file, 'r') as f:
            tweets = [line.strip() for line in f if line.strip()]
        
        for tweet in tweets:
            result = analyze_tweet(tweet)
            if args.json:
                print(json.dumps({
                    "tweet": tweet,
                    "score": result.score,
                    "engagement_potential": {k.value: v for k, v in result.engagement_potential.items()},
                    "suggestions": result.suggestions,
                    "warnings": result.warnings
                }))
            else:
                print(format_result(result, tweet))
                print()
    elif args.tweet:
        result = analyze_tweet(args.tweet)
        if args.json:
            print(json.dumps({
                "tweet": args.tweet,
                "score": result.score,
                "engagement_potential": {k.value: v for k, v in result.engagement_potential.items()},
                "suggestions": result.suggestions,
                "warnings": result.warnings
            }, indent=2))
        else:
            print(format_result(result, args.tweet))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
