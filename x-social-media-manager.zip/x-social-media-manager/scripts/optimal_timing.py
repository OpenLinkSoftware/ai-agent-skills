#!/usr/bin/env python3
"""
Optimal Posting Time Calculator

Calculates the best times to post on X based on audience timezone distribution
and general engagement patterns.

Usage:
    python optimal_timing.py --timezone "US/Eastern"
    python optimal_timing.py --audience "US:60,Europe:30,Asia:10"
    python optimal_timing.py --analyze-times "9:00,12:00,17:00,20:00"
"""

import argparse
from typing import Dict, List, Tuple
from dataclasses import dataclass
import json


@dataclass
class TimeSlot:
    hour: int
    minute: int = 0
    
    def __str__(self):
        return f"{self.hour:02d}:{self.minute:02d}"
    
    @classmethod
    def from_string(cls, s: str) -> 'TimeSlot':
        parts = s.split(':')
        return cls(int(parts[0]), int(parts[1]) if len(parts) > 1 else 0)


# Engagement patterns by hour (0-23) - baseline US Eastern
BASE_ENGAGEMENT_PATTERN = {
    0: 15, 1: 10, 2: 8, 3: 5, 4: 5, 5: 10,
    6: 25, 7: 45, 8: 70, 9: 85, 10: 75, 11: 65,
    12: 80, 13: 70, 14: 60, 15: 55, 16: 60, 17: 75,
    18: 80, 19: 70, 20: 65, 21: 55, 22: 40, 23: 25
}

# Weekend adjustment
WEEKEND_ADJUSTMENT = {
    0: 5, 1: 5, 2: 5, 3: 0, 4: 0, 5: -5,
    6: -10, 7: -15, 8: -10, 9: 5, 10: 10, 11: 10,
    12: 5, 13: 5, 14: 5, 15: 5, 16: 0, 17: 0,
    18: 0, 19: 5, 20: 10, 21: 10, 22: 10, 23: 10
}

# Timezone offsets from US Eastern
TIMEZONE_OFFSETS = {
    "US/Pacific": -3, "US/Mountain": -2, "US/Central": -1, "US/Eastern": 0,
    "America/Sao_Paulo": 2, "Europe/London": 5, "Europe/Paris": 6,
    "Asia/Dubai": 9, "Asia/Singapore": 13, "Asia/Tokyo": 14, "Australia/Sydney": 15,
}

REGION_TIMEZONES = {
    "US": ["US/Eastern", "US/Central", "US/Pacific"],
    "Europe": ["Europe/London", "Europe/Paris"],
    "Asia": ["Asia/Singapore", "Asia/Tokyo"],
}


def get_engagement_score(hour: int, is_weekend: bool = False) -> int:
    base = BASE_ENGAGEMENT_PATTERN.get(hour, 50)
    if is_weekend:
        return max(0, min(100, base + WEEKEND_ADJUSTMENT.get(hour, 0)))
    return base


def calculate_weighted_engagement(hour: int, audience: Dict[str, float], is_weekend: bool = False) -> float:
    total_score, total_weight = 0, 0
    for tz, weight in audience.items():
        offset = TIMEZONE_OFFSETS.get(tz, 0)
        local_hour = (hour - offset) % 24
        total_score += get_engagement_score(local_hour, is_weekend) * weight
        total_weight += weight
    return total_score / total_weight if total_weight else 0


def find_optimal_times(audience: Dict[str, float], num_posts: int = 3, 
                       is_weekend: bool = False, min_gap: int = 3) -> List[Tuple[TimeSlot, float]]:
    hour_scores = [(h, calculate_weighted_engagement(h, audience, is_weekend)) for h in range(24)]
    hour_scores.sort(key=lambda x: x[1], reverse=True)
    
    selected = []
    for hour, score in hour_scores:
        if not any(min(abs(hour - sh), 24 - abs(hour - sh)) < min_gap for sh, _ in selected):
            selected.append((TimeSlot(hour), score))
            if len(selected) >= num_posts:
                break
    
    selected.sort(key=lambda x: x[0].hour)
    return selected


def parse_audience_string(audience_str: str) -> Dict[str, float]:
    distribution = {}
    for part in audience_str.split(','):
        region, pct = part.strip().split(':')
        region, pct = region.strip(), float(pct.strip())
        if region in REGION_TIMEZONES:
            for tz in REGION_TIMEZONES[region]:
                distribution[tz] = distribution.get(tz, 0) + pct / len(REGION_TIMEZONES[region])
        elif region in TIMEZONE_OFFSETS:
            distribution[region] = distribution.get(region, 0) + pct
    return distribution


def get_recommendation(score: float) -> str:
    if score >= 75: return "🟢 Excellent"
    elif score >= 60: return "🟡 Good"
    elif score >= 40: return "🟠 Fair"
    return "🔴 Poor"


def main():
    parser = argparse.ArgumentParser(description="Calculate optimal X posting times")
    parser.add_argument("--timezone", "-t", default="US/Eastern")
    parser.add_argument("--audience", "-a", default="US:70,Europe:20,Asia:10")
    parser.add_argument("--posts-per-day", "-p", type=int, default=3)
    parser.add_argument("--min-gap", "-g", type=int, default=3)
    parser.add_argument("--json", "-j", action="store_true")
    args = parser.parse_args()
    
    audience = parse_audience_string(args.audience)
    weekday = find_optimal_times(audience, args.posts_per_day, False, args.min_gap)
    weekend = find_optimal_times(audience, args.posts_per_day, True, args.min_gap)
    
    if args.json:
        print(json.dumps({
            "weekday": [{"time": str(s), "score": round(sc, 1)} for s, sc in weekday],
            "weekend": [{"time": str(s), "score": round(sc, 1)} for s, sc in weekend]
        }, indent=2))
    else:
        print(f"\n{'='*50}\nOPTIMAL POSTING TIMES ({args.timezone})\n{'='*50}")
        print("\n📆 WEEKDAYS:")
        for slot, score in weekday:
            print(f"  {slot} - {score:.0f}/100 {get_recommendation(score)}")
        print("\n📆 WEEKENDS:")
        for slot, score in weekend:
            print(f"  {slot} - {score:.0f}/100 {get_recommendation(score)}")


if __name__ == "__main__":
    main()
