#!/usr/bin/env python3
"""
Content Calendar Generator

Generates a weekly content calendar optimized for the X algorithm,
with balanced content types and strategic posting times.

Usage:
    python content_calendar.py --niche "tech" --posts-per-day 3
    python content_calendar.py --output calendar.json --weeks 4
"""

import argparse
import json
from datetime import datetime, timedelta
from typing import List, Dict
from dataclasses import dataclass, asdict
import random


@dataclass
class ContentSlot:
    day: str
    time: str
    content_type: str
    format: str
    prompt: str
    engagement_goal: str
    notes: str


# Content type distribution (aligned with algorithm optimization)
CONTENT_TYPES = {
    "value_educational": {
        "weight": 40,
        "formats": ["thread", "tip_list", "how_to", "breakdown"],
        "engagement_goal": "reposts, bookmarks",
        "description": "Educational content that provides actionable value"
    },
    "engagement_questions": {
        "weight": 25,
        "formats": ["open_question", "poll_style", "debate", "fill_blank"],
        "engagement_goal": "replies",
        "description": "Content designed to drive conversation"
    },
    "personal_story": {
        "weight": 20,
        "formats": ["story", "lesson_learned", "behind_scenes", "journey_update"],
        "engagement_goal": "replies, follows",
        "description": "Personal content that builds connection"
    },
    "promotional": {
        "weight": 15,
        "formats": ["soft_cta", "case_study", "testimonial", "announcement"],
        "engagement_goal": "clicks, conversions",
        "description": "Promotional content (use sparingly)"
    }
}

# Format-specific prompts by niche
NICHE_PROMPTS = {
    "tech": {
        "thread": [
            "Break down a complex technical concept your audience struggles with",
            "Share your tech stack and why you chose each tool",
            "Explain a recent project's architecture decisions",
        ],
        "tip_list": [
            "X productivity tools/shortcuts you use daily",
            "Common coding mistakes and how to avoid them",
            "Resources that leveled up your skills",
        ],
        "open_question": [
            "What's your most controversial tech opinion?",
            "What tool do you wish existed?",
            "What's the best piece of code you've ever written?",
        ],
        "story": [
            "Share a debugging war story",
            "Your journey into tech",
            "A project that completely failed and what you learned",
        ],
    },
    "business": {
        "thread": [
            "Break down a successful company's strategy",
            "Share your business's growth playbook",
            "Explain a counterintuitive business decision you made",
        ],
        "tip_list": [
            "Books that changed how you think about business",
            "Lessons from your biggest business mistake",
            "Negotiation tactics that actually work",
        ],
        "open_question": [
            "What's the best business advice you've ever received?",
            "What would you do differently if starting over?",
            "What's overrated in your industry?",
        ],
        "story": [
            "Your company's origin story",
            "A deal that almost fell through",
            "The moment you knew your business would work",
        ],
    },
    "creator": {
        "thread": [
            "Your content creation process from idea to publish",
            "How you grew from 0 to X followers",
            "Tools and systems that power your content",
        ],
        "tip_list": [
            "Lessons from your first year creating content",
            "Ways to repurpose one piece of content",
            "Mistakes new creators make",
        ],
        "open_question": [
            "What's your biggest content creation struggle?",
            "What type of content do you want to see more of?",
            "How do you stay consistent?",
        ],
        "story": [
            "Your viral moment and what happened after",
            "Why you started creating content",
            "A collaboration that changed your trajectory",
        ],
    },
    "general": {
        "thread": [
            "Share expertise from your field that others would find valuable",
            "Break down a topic you've researched deeply",
            "Lessons from a major life/career transition",
        ],
        "tip_list": [
            "Habits that improved your productivity",
            "Resources that leveled up your skills",
            "Mistakes you made and how others can avoid them",
        ],
        "open_question": [
            "What's a hill you'll die on in your field?",
            "What would you tell your younger self?",
            "What's something you changed your mind about recently?",
        ],
        "story": [
            "A failure that led to success",
            "The moment everything clicked",
            "An unexpected lesson from an unlikely source",
        ],
    }
}

# Default prompts for formats not covered
DEFAULT_PROMPTS = {
    "how_to": ["Create a step-by-step guide for something your audience struggles with"],
    "breakdown": ["Analyze something trending in your industry"],
    "poll_style": ["Create an A vs B comparison your audience has opinions on"],
    "debate": ["Share a controversial but defensible opinion"],
    "fill_blank": ["Create a 'finish this sentence' prompt relevant to your niche"],
    "lesson_learned": ["Share a recent lesson from experience"],
    "behind_scenes": ["Show your process or workspace"],
    "journey_update": ["Share progress on a goal or project"],
    "soft_cta": ["Mention your product/service in context of value"],
    "case_study": ["Share a success story or result"],
    "testimonial": ["Share feedback you've received"],
    "announcement": ["Announce something new"],
}

# Optimal posting times by slot
POSTING_TIMES = {
    "morning": ["08:00", "09:00", "09:30"],
    "midday": ["12:00", "12:30", "13:00"],
    "afternoon": ["15:00", "16:00", "16:30"],
    "evening": ["17:30", "18:00", "19:00"],
}


def get_prompt(format_type: str, niche: str) -> str:
    """Get a content prompt for the given format and niche."""
    niche_data = NICHE_PROMPTS.get(niche, NICHE_PROMPTS["general"])
    prompts = niche_data.get(format_type, DEFAULT_PROMPTS.get(format_type, ["Create content in this format"]))
    return random.choice(prompts)


def generate_weekly_calendar(
    niche: str,
    posts_per_day: int = 3,
    start_date: datetime = None
) -> List[ContentSlot]:
    """Generate a week of content slots."""
    
    if start_date is None:
        start_date = datetime.now()
        # Start from next Monday
        days_until_monday = (7 - start_date.weekday()) % 7
        if days_until_monday == 0:
            days_until_monday = 7
        start_date = start_date + timedelta(days=days_until_monday)
    
    calendar = []
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    
    # Calculate posts per content type for the week
    total_posts = posts_per_day * 7
    type_distribution = {}
    for ctype, data in CONTENT_TYPES.items():
        type_distribution[ctype] = int(total_posts * data["weight"] / 100)
    
    # Adjust for rounding
    diff = total_posts - sum(type_distribution.values())
    if diff > 0:
        type_distribution["value_educational"] += diff
    
    # Create pool of content assignments
    content_pool = []
    for ctype, count in type_distribution.items():
        for _ in range(count):
            format_choice = random.choice(CONTENT_TYPES[ctype]["formats"])
            content_pool.append({
                "type": ctype,
                "format": format_choice,
                "goal": CONTENT_TYPES[ctype]["engagement_goal"],
                "description": CONTENT_TYPES[ctype]["description"]
            })
    
    random.shuffle(content_pool)
    
    # Assign to days and times
    pool_index = 0
    time_slots = ["morning", "midday", "evening"][:posts_per_day]
    
    for day_num, day_name in enumerate(days):
        date = start_date + timedelta(days=day_num)
        
        for slot_name in time_slots:
            if pool_index >= len(content_pool):
                break
                
            content = content_pool[pool_index]
            time = random.choice(POSTING_TIMES[slot_name])
            
            slot = ContentSlot(
                day=f"{day_name} ({date.strftime('%m/%d')})",
                time=time,
                content_type=content["type"].replace("_", " ").title(),
                format=content["format"].replace("_", " ").title(),
                prompt=get_prompt(content["format"], niche),
                engagement_goal=content["goal"],
                notes=content["description"]
            )
            calendar.append(slot)
            pool_index += 1
    
    return calendar


def format_calendar_text(calendar: List[ContentSlot]) -> str:
    """Format calendar for text display."""
    output = []
    output.append("=" * 70)
    output.append("WEEKLY CONTENT CALENDAR")
    output.append("=" * 70)
    
    current_day = None
    for slot in calendar:
        if slot.day != current_day:
            current_day = slot.day
            output.append(f"\n{'─' * 70}")
            output.append(f"📅 {current_day}")
            output.append(f"{'─' * 70}")
        
        output.append(f"\n  ⏰ {slot.time}")
        output.append(f"  📝 Type: {slot.content_type}")
        output.append(f"  📋 Format: {slot.format}")
        output.append(f"  🎯 Goal: {slot.engagement_goal}")
        output.append(f"  💡 Prompt: {slot.prompt}")
    
    output.append("\n" + "=" * 70)
    output.append("CONTENT MIX SUMMARY")
    output.append("=" * 70)
    
    # Count by type
    type_counts = {}
    for slot in calendar:
        type_counts[slot.content_type] = type_counts.get(slot.content_type, 0) + 1
    
    total = len(calendar)
    for ctype, count in sorted(type_counts.items()):
        pct = count / total * 100
        bar = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))
        output.append(f"  {ctype:25} [{bar}] {count} posts ({pct:.0f}%)")
    
    return "\n".join(output)


def format_calendar_markdown(calendar: List[ContentSlot]) -> str:
    """Format calendar as markdown table."""
    output = []
    output.append("# Weekly Content Calendar\n")
    output.append("| Day | Time | Type | Format | Prompt | Goal |")
    output.append("|-----|------|------|--------|--------|------|")
    
    for slot in calendar:
        output.append(f"| {slot.day} | {slot.time} | {slot.content_type} | {slot.format} | {slot.prompt} | {slot.engagement_goal} |")
    
    return "\n".join(output)


def main():
    parser = argparse.ArgumentParser(description="Generate X content calendar")
    parser.add_argument("--niche", "-n", default="general",
                       choices=["tech", "business", "creator", "general"])
    parser.add_argument("--posts-per-day", "-p", type=int, default=3)
    parser.add_argument("--weeks", "-w", type=int, default=1)
    parser.add_argument("--output", "-o", help="Output file path")
    parser.add_argument("--format", "-f", choices=["text", "json", "markdown"], default="text")
    
    args = parser.parse_args()
    
    all_calendars = []
    start = datetime.now()
    
    for week in range(args.weeks):
        week_start = start + timedelta(weeks=week)
        calendar = generate_weekly_calendar(args.niche, args.posts_per_day, week_start)
        all_calendars.extend(calendar)
    
    # Format output
    if args.format == "json":
        output = json.dumps([asdict(slot) for slot in all_calendars], indent=2)
    elif args.format == "markdown":
        output = format_calendar_markdown(all_calendars)
    else:
        output = format_calendar_text(all_calendars)
    
    # Write or print
    if args.output:
        with open(args.output, 'w') as f:
            f.write(output)
        print(f"Calendar saved to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
